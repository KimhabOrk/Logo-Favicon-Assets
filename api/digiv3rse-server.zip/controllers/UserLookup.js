'use strict';

var utils = require('../utils/writer.js');
var UserLookup = require('../service/UserLookupService');

module.exports.v1MeGET = function v1MeGET (req, res, next) {
  UserLookup.v1MeGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersByGET = function v1UsersByGET (req, res, next, usernames) {
  UserLookup.v1UsersByGET(usernames)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersByUsernameUsernameGET = function v1UsersByUsernameUsernameGET (req, res, next, username) {
  UserLookup.v1UsersByUsernameUsernameGET(username)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersGET = function v1UsersGET (req, res, next, ids) {
  UserLookup.v1UsersGET(ids)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdGET = function v1UsersIdGET (req, res, next, id) {
  UserLookup.v1UsersIdGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
