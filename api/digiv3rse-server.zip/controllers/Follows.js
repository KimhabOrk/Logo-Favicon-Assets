'use strict';

var utils = require('../utils/writer.js');
var Follows = require('../service/FollowsService');

module.exports.v1UsersIdFollowersGET = function v1UsersIdFollowersGET (req, res, next, id) {
  Follows.v1UsersIdFollowersGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdFollowingGET = function v1UsersIdFollowingGET (req, res, next, id) {
  Follows.v1UsersIdFollowingGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdFollowingPOST = function v1UsersIdFollowingPOST (req, res, next, body, id) {
  Follows.v1UsersIdFollowingPOST(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersSource_user_idFollowingTarget_user_idDELETE = function v1UsersSource_user_idFollowingTarget_user_idDELETE (req, res, next, source_user_id, target_user_id) {
  Follows.v1UsersSource_user_idFollowingTarget_user_idDELETE(source_user_id, target_user_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
