'use strict';

var utils = require('../utils/writer.js');
var FilteredStream = require('../service/FilteredStreamService');

module.exports.v1PostsSearchStreamGET = function v1PostsSearchStreamGET (req, res, next) {
  FilteredStream.v1PostsSearchStreamGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1PostsSearchStreamRulesGET = function v1PostsSearchStreamRulesGET (req, res, next) {
  FilteredStream.v1PostsSearchStreamRulesGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1PostsSearchStreamRulesPOST = function v1PostsSearchStreamRulesPOST (req, res, next, body) {
  FilteredStream.v1PostsSearchStreamRulesPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
