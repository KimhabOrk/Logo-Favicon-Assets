'use strict';

var utils = require('../utils/writer.js');
var Mutes = require('../service/MutesService');

module.exports.v1UsersIdMutingGET = function v1UsersIdMutingGET (req, res, next, id, ) {
  Mutes.v1UsersIdMutingGET(id, )
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdMutingPOST = function v1UsersIdMutingPOST (req, res, next, body, id) {
  Mutes.v1UsersIdMutingPOST(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersSource_user_idMutingTarget_user_idDELETE = function v1UsersSource_user_idMutingTarget_user_idDELETE (req, res, next, source_user_id, target_user_id) {
  Mutes.v1UsersSource_user_idMutingTarget_user_idDELETE(source_user_id, target_user_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
