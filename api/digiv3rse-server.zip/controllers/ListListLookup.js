'use strict';

var utils = require('../utils/writer.js');
var ListListLookup = require('../service/ListListLookupService');

module.exports.v1ListsIdGET = function v1ListsIdGET (req, res, next, id) {
  ListListLookup.v1ListsIdGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdOwned_listsGET = function v1UsersIdOwned_listsGET (req, res, next, id, ) {
  ListListLookup.v1UsersIdOwned_listsGET(id, )
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
