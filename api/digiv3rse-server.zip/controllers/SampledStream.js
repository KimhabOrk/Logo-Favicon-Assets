'use strict';

var utils = require('../utils/writer.js');
var SampledStream = require('../service/SampledStreamService');

module.exports.v1PostsSampleStreamGET = function v1PostsSampleStreamGET (req, res, next) {
  SampledStream.v1PostsSampleStreamGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
