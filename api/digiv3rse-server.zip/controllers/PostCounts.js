'use strict';

var utils = require('../utils/writer.js');
var PostCounts = require('../service/PostCountsService');

module.exports.v1PostsCountsAllGET = function v1PostsCountsAllGET (req, res, next, query) {
  PostCounts.v1PostsCountsAllGET(query)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1PostsCountsRecentGET = function v1PostsCountsRecentGET (req, res, next, query) {
  PostCounts.v1PostsCountsRecentGET(query)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
