'use strict';

var utils = require('../utils/writer.js');
var ManageDirectMessages = require('../service/ManageDirectMessagesService');

module.exports.v1Dm_conversationsDm_conversation_idMessagesPOST = function v1Dm_conversationsDm_conversation_idMessagesPOST (req, res, next, body, dm_conversation_id) {
  ManageDirectMessages.v1Dm_conversationsDm_conversation_idMessagesPOST(body, dm_conversation_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1Dm_conversationsPOST = function v1Dm_conversationsPOST (req, res, next, body) {
  ManageDirectMessages.v1Dm_conversationsPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1Dm_conversationsWithParticipant_idMessagesPOST = function v1Dm_conversationsWithParticipant_idMessagesPOST (req, res, next, body, participant_id) {
  ManageDirectMessages.v1Dm_conversationsWithParticipant_idMessagesPOST(body, participant_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
