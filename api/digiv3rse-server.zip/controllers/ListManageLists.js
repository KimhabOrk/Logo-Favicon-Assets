'use strict';

var utils = require('../utils/writer.js');
var ListManageLists = require('../service/ListManageListsService');

module.exports.v1ListsIdDELETE = function v1ListsIdDELETE (req, res, next, id) {
  ListManageLists.v1ListsIdDELETE(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1ListsIdPUT = function v1ListsIdPUT (req, res, next, body, id) {
  ListManageLists.v1ListsIdPUT(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1ListsPOST = function v1ListsPOST (req, res, next, body) {
  ListManageLists.v1ListsPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
