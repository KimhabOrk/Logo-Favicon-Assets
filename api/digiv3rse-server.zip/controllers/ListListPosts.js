'use strict';

var utils = require('../utils/writer.js');
var ListListPosts = require('../service/ListListPostsService');

module.exports.v1ListsIdPostsGET = function v1ListsIdPostsGET (req, res, next, id, ) {
  ListListPosts.v1ListsIdPostsGET(id, )
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
