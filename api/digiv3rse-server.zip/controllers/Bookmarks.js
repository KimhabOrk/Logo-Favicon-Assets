'use strict';

var utils = require('../utils/writer.js');
var Bookmarks = require('../service/BookmarksService');

module.exports.v1UsersIdBookmarksGET = function v1UsersIdBookmarksGET (req, res, next, id) {
  Bookmarks.v1UsersIdBookmarksGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdBookmarksPOST = function v1UsersIdBookmarksPOST (req, res, next, body, id) {
  Bookmarks.v1UsersIdBookmarksPOST(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdBookmarksTweet_idDELETE = function v1UsersIdBookmarksTweet_idDELETE (req, res, next, id, tweet_id) {
  Bookmarks.v1UsersIdBookmarksTweet_idDELETE(id, tweet_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
