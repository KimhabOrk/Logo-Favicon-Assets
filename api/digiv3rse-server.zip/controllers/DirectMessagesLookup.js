'use strict';

var utils = require('../utils/writer.js');
var DirectMessagesLookup = require('../service/DirectMessagesLookupService');

module.exports.v1Dm_conversationsDm_conversation_idDm_eventsGET = function v1Dm_conversationsDm_conversation_idDm_eventsGET (req, res, next, dm_conversation_id, dm_event.fields, post.fields, expansions) {
  DirectMessagesLookup.v1Dm_conversationsDm_conversation_idDm_eventsGET(dm_conversation_id, dm_event.fields, post.fields, expansions)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1Dm_conversationsWithParticipant_idDm_eventsGET = function v1Dm_conversationsWithParticipant_idDm_eventsGET (req, res, next, participant_id, dm_event.fields) {
  DirectMessagesLookup.v1Dm_conversationsWithParticipant_idDm_eventsGET(participant_id, dm_event.fields)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1Dm_eventsGET = function v1Dm_eventsGET (req, res, next, dm_event.fields, event_types, user.fields, expansions) {
  DirectMessagesLookup.v1Dm_eventsGET(dm_event.fields, event_types, user.fields, expansions)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
