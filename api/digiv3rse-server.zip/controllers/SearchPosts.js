'use strict';

var utils = require('../utils/writer.js');
var SearchPosts = require('../service/SearchPostsService');

module.exports.v1PostsSearchAllGET = function v1PostsSearchAllGET (req, res, next, query) {
  SearchPosts.v1PostsSearchAllGET(query)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1PostsSearchRecentGET = function v1PostsSearchRecentGET (req, res, next, query) {
  SearchPosts.v1PostsSearchRecentGET(query)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
