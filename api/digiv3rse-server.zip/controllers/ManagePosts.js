'use strict';

var utils = require('../utils/writer.js');
var ManagePosts = require('../service/ManagePostsService');

module.exports.v1PostsIdDELETE = function v1PostsIdDELETE (req, res, next, id) {
  ManagePosts.v1PostsIdDELETE(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1PostsPOST = function v1PostsPOST (req, res, next, body) {
  ManagePosts.v1PostsPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
