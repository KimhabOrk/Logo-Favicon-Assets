'use strict';

var utils = require('../utils/writer.js');
var PostLookup = require('../service/PostLookupService');

module.exports.v1PostsGET = function v1PostsGET (req, res, next, ids) {
  PostLookup.v1PostsGET(ids)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1PostsIdGET = function v1PostsIdGET (req, res, next, id) {
  PostLookup.v1PostsIdGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
