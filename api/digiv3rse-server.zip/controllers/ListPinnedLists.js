'use strict';

var utils = require('../utils/writer.js');
var ListPinnedLists = require('../service/ListPinnedListsService');

module.exports.v1ListsIdPinned_listsList_idDELETE = function v1ListsIdPinned_listsList_idDELETE (req, res, next, id, list_id) {
  ListPinnedLists.v1ListsIdPinned_listsList_idDELETE(id, list_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdPinned_listsGET = function v1UsersIdPinned_listsGET (req, res, next, id, ) {
  ListPinnedLists.v1UsersIdPinned_listsGET(id, )
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdPinned_listsPOST = function v1UsersIdPinned_listsPOST (req, res, next, body, id) {
  ListPinnedLists.v1UsersIdPinned_listsPOST(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
