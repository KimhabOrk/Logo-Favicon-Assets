'use strict';

var utils = require('../utils/writer.js');
var Reposts = require('../service/RepostsService');

module.exports.v1PostsIdRetweeted_byGET = function v1PostsIdRetweeted_byGET (req, res, next, id) {
  Reposts.v1PostsIdRetweeted_byGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdRetweetsPOST = function v1UsersIdRetweetsPOST (req, res, next, body, id) {
  Reposts.v1UsersIdRetweetsPOST(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdRetweetsSource_post_idDELETE = function v1UsersIdRetweetsSource_post_idDELETE (req, res, next, id, source_post_id) {
  Reposts.v1UsersIdRetweetsSource_post_idDELETE(id, source_post_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
