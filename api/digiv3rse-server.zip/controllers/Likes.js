'use strict';

var utils = require('../utils/writer.js');
var Likes = require('../service/LikesService');

module.exports.v1PostsIdLiking_usersGET = function v1PostsIdLiking_usersGET (req, res, next, id) {
  Likes.v1PostsIdLiking_usersGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdLiked_tweetsGET = function v1UsersIdLiked_tweetsGET (req, res, next, id) {
  Likes.v1UsersIdLiked_tweetsGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdLikesPOST = function v1UsersIdLikesPOST (req, res, next, body, id) {
  Likes.v1UsersIdLikesPOST(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdLikesTweet_idDELETE = function v1UsersIdLikesTweet_idDELETE (req, res, next, id, tweet_id) {
  Likes.v1UsersIdLikesTweet_idDELETE(id, tweet_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
