'use strict';

var utils = require('../utils/writer.js');
var Blocks = require('../service/BlocksService');

module.exports.v1UsersIdBlockingGET = function v1UsersIdBlockingGET (req, res, next, id) {
  Blocks.v1UsersIdBlockingGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdBlockingPOST = function v1UsersIdBlockingPOST (req, res, next, body, id) {
  Blocks.v1UsersIdBlockingPOST(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersSource_user_idBlockingTarget_user_idDELETE = function v1UsersSource_user_idBlockingTarget_user_idDELETE (req, res, next, source_user_id, target_user_id) {
  Blocks.v1UsersSource_user_idBlockingTarget_user_idDELETE(source_user_id, target_user_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
