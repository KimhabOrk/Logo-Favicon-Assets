'use strict';

var utils = require('../utils/writer.js');
var Timelines = require('../service/TimelinesService');

module.exports.v1UsersIdMentionsGET = function v1UsersIdMentionsGET (req, res, next, id) {
  Timelines.v1UsersIdMentionsGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdPostsGET = function v1UsersIdPostsGET (req, res, next, id) {
  Timelines.v1UsersIdPostsGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdTimelinesReverse_chronologicalGET = function v1UsersIdTimelinesReverse_chronologicalGET (req, res, next, id, , ) {
  Timelines.v1UsersIdTimelinesReverse_chronologicalGET(id, , )
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
