'use strict';

var utils = require('../utils/writer.js');
var ListListFollows = require('../service/ListListFollowsService');

module.exports.v1ListsIdFollowersGET = function v1ListsIdFollowersGET (req, res, next, id, ) {
  ListListFollows.v1ListsIdFollowersGET(id, )
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdFollowed_listsGET = function v1UsersIdFollowed_listsGET (req, res, next, id, ) {
  ListListFollows.v1UsersIdFollowed_listsGET(id, )
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdFollowed_listsList_idDELETE = function v1UsersIdFollowed_listsList_idDELETE (req, res, next, id, list_id) {
  ListListFollows.v1UsersIdFollowed_listsList_idDELETE(id, list_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdFollowed_listsPOST = function v1UsersIdFollowed_listsPOST (req, res, next, body, id) {
  ListListFollows.v1UsersIdFollowed_listsPOST(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
