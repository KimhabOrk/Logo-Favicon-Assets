'use strict';

var utils = require('../utils/writer.js');
var ListListMembers = require('../service/ListListMembersService');

module.exports.v1ListsIdMembersGET = function v1ListsIdMembersGET (req, res, next, id, ) {
  ListListMembers.v1ListsIdMembersGET(id, )
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1ListsIdMembersPOST = function v1ListsIdMembersPOST (req, res, next, body, id) {
  ListListMembers.v1ListsIdMembersPOST(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1ListsIdMembersUser_idDELETE = function v1ListsIdMembersUser_idDELETE (req, res, next, id, user_id) {
  ListListMembers.v1ListsIdMembersUser_idDELETE(id, user_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.v1UsersIdList_membershipsGET = function v1UsersIdList_membershipsGET (req, res, next, id, ) {
  ListListMembers.v1UsersIdList_membershipsGET(id, )
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
