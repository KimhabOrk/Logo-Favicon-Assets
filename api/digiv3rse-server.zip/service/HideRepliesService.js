'use strict';


/**
 * Unhide a reply
 * Provides the ability to unhide a reply to a Post.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/hide-replies/api-reference/put-posts-id-hidden) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * id String Required. Enter a single Post ID.
 * contentType String  (optional)
 * no response value expected for this operation
 **/
exports.v1PostsIdHiddenPUT = function(body,id,contentType) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

