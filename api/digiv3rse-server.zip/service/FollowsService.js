'use strict';


/**
 * Followers of user ID
 * Returns a list of users who are followers of the specified user ID.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/follows/api-reference/get-users-id-followers) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. Enter a single user ID.
 * no response value expected for this operation
 **/
exports.v1UsersIdFollowersGET = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Users a user ID is following
 * Returns a list of users the specified user ID is following.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/follows/api-reference/get-users-id-following) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. Enter a single user ID.
 * no response value expected for this operation
 **/
exports.v1UsersIdFollowingGET = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Follow a user ID
 * Allows a user ID to follow another user.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/follows/api-reference/post-users-source_user_id-following) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * id String The ID of the user who wishes to follow an account. The ID must belong to the authenticating user.  In Postman, you can leave the `id` field empty to let the collection automatically populate it with the user ID of the user in the current environment.
 * no response value expected for this operation
 **/
exports.v1UsersIdFollowingPOST = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Unfollow a user ID
 * Allows a user ID to unfollow another user.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/follows/api-reference/delete-users-source_user_id-following) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * source_user_id String The ID of the user who wishes to follow an account. The ID must belong to the authenticating user.  In Postman, you can leave the `source_user_id` field empty to let the collection automatically populate it with the user ID of the user in the current environment.
 * target_user_id String The ID of the user to unfollow.
 * no response value expected for this operation
 **/
exports.v1UsersSource_user_idFollowingTarget_user_idDELETE = function(source_user_id,target_user_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

