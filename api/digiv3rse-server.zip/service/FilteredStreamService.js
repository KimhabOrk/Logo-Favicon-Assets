'use strict';


/**
 * Stream (see description)
 * Streams Posts in real-time based on a specific set of filter rules.  Please note streaming responses are currently [not supported](https://github.com/postmanlabs/postman-app-support/issues/5040) in Postman. Use this to help form your request, then click on Code > cURL. Copy the cURL command and paste in terminal to view the response.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * no response value expected for this operation
 **/
exports.v1PostsSearchStreamGET = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Retrieve Rules
 * Returns a list of filter rules currently active on the streaming endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * returns Object
 **/
exports.v1PostsSearchStreamRulesGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Rules (by rule value)
 * Delete filter rules. To delete one or more rules, submit a delete object payload with an array of rule values to delete.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * returns Object
 **/
exports.v1PostsSearchStreamRulesPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

