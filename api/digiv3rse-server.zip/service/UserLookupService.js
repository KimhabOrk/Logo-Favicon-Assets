'use strict';


/**
 * Authenticated User Lookup
 * This endpoint returns the information about an authorized user.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/lookup/api-reference/get-users-me) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * returns Object
 **/
exports.v1MeGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Users by Username
 * This endpoint returns details about up to 100 users specified by username.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/lookup/api-reference/get-users-by) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * usernames String Required. Enter up to 100 comma-separated usernames. (optional)
 * returns Object
 **/
exports.v1UsersByGET = function(usernames) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * User by Username
 * This endpoint returns details about a user by username.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/lookup/api-reference/get-users-by-username-username) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * username String Required. Enter a single DiGiVerse username (handle).
 * returns Object
 **/
exports.v1UsersByUsernameUsernameGET = function(username) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Users by ID
 * This endpoint returns details about up to 100 users by ID.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/lookup/api-reference/get-users) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * ids String Required. Enter up to 100 comma-separated user IDs. (optional)
 * returns Object
 **/
exports.v1UsersGET = function(ids) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * User by ID
 * This endpoint returns details about a user by ID.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/lookup/api-reference/get-users-id) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. Enter a single user ID.
 * returns Object
 **/
exports.v1UsersIdGET = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

