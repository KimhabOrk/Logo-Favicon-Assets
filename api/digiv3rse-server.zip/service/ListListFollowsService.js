'use strict';


/**
 * Follower lookup
 * This endpoint returns follower details from the List specified by the requested ID  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/list-follows/api-reference/get-lists-id-followers) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The ID of the List you wish to recieve follower details on.
 *  String  (optional)
 * no response value expected for this operation
 **/
exports.v1ListsIdFollowersGET = function(id,) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * User's followed Lists
 * This endpoint returns details on Lists a user follows specified by the requested ID  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/list-follows/api-reference/get-users-id-followed_lists) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The ID of the user you wish to recieve details on which Lists they follow.
 *  String  (optional)
 * no response value expected for this operation
 **/
exports.v1UsersIdFollowed_listsGET = function(id,) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Unfollow a list
 * Allows the authenticated user to unfollow a specified List.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/manage-lists/api-reference/delete-users-id-followed-lists-list_id) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The ID of the authenticated user 
 * list_id String Required. The ID of the List you wish to unfollow 
 * no response value expected for this operation
 **/
exports.v1UsersIdFollowed_listsList_idDELETE = function(id,list_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Follow a list
 * Allows the authenticated user to follow a specified List.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/manage-lists/api-reference/post-users-id-followed-lists) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * id String Required. The ID of the authenticated user 
 * no response value expected for this operation
 **/
exports.v1UsersIdFollowed_listsPOST = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

