'use strict';


/**
 * Liking users
 * Returns a list of users who have liked a specified Post ID.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/likes/api-reference/get-posts-id-liking_users) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The Post ID of the Post to request liking users of.
 * no response value expected for this operation
 **/
exports.v1PostsIdLiking_usersGET = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Liked Posts
 * Returns a list of Posts that have been liked by a specified user ID.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/likes/api-reference/get-users-id-liked_tweets) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. User ID of the user to request liked Posts for.
 * no response value expected for this operation
 **/
exports.v1UsersIdLiked_tweetsGET = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Like a Post
 * Allows an authenticated user to like a Post.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/likes/api-reference/post-users-user_id-likes) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * id String The ID of the user who wishes to like a Post. The ID must belong to the authenticating user. 
 * no response value expected for this operation
 **/
exports.v1UsersIdLikesPOST = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Unlike a Post
 * Allows an authenticated user to unlike a Post.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/likes/api-reference/delete-users-user_id-likes) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String The ID of the user who wishes to unlike a Post. The ID must belong to the authenticating user. 
 * tweet_id String The ID of the Post to be unliked
 * no response value expected for this operation
 **/
exports.v1UsersIdLikesTweet_idDELETE = function(id,tweet_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

