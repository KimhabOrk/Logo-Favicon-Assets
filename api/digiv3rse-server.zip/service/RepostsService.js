'use strict';


/**
 * Retweeted by
 * Returns a list of users who have liked a specified Post ID.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/reweets/api-reference/get-posts-id-retweeted_by) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The Post ID of the Post to request Retweeting users of.
 * no response value expected for this operation
 **/
exports.v1PostsIdRetweeted_byGET = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Repost a Post
 * Allows an authenticated user to Repost a Post.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/post-users-id-retweets) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * id String The ID of the user who wishes to Repost a Post. The ID must belong to the authenticating user. 
 * no response value expected for this operation
 **/
exports.v1UsersIdRetweetsPOST = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Undo a Repost
 * Allows an authenticated user to unlike a Post.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/reweets/api-reference/delete-users-id-retweets-tweet_id) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String The ID of the user who wishes to undo a Reweet. The ID must belong to the authenticating user. 
 * source_post_id String The ID of the Post to remove of Repost of
 * no response value expected for this operation
 **/
exports.v1UsersIdRetweetsSource_post_idDELETE = function(id,source_post_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

