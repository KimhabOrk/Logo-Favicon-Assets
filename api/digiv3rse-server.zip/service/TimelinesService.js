'use strict';


/**
 * User mention timeline by ID
 * Allows you to retrieve a collection of the most recent Posts and Retweets posted by you or a user you follow. This endpoint returns up to the last 3200 Posts.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/timelines/api-reference/get-users-id-mentions) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. Enter a single user ID.
 * no response value expected for this operation
 **/
exports.v1UsersIdMentionsGET = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * User Post timeline by ID
 * Returns the most recent Posts composed by a single user specified by the requested user ID.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/timelines/api-reference/get-users-id-posts) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. Enter a single user ID.
 * no response value expected for this operation
 **/
exports.v1UsersIdPostsGET = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Reverse chronological home timeline by ID
 * Allows you to retrieve a collection of the most recent Posts and Retweets posted by you or a user you follow. This endpoint can return every Post created on a timeline over the last 7 days and the most recent 800 regardless of the creation date.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/timelines/api-reference/get-users-id-mentions) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String 
 *  String  (optional)
 *  String  (optional)
 * no response value expected for this operation
 **/
exports.v1UsersIdTimelinesReverse_chronologicalGET = function(id,,) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

