'use strict';


/**
 * Multiple Posts
 * This endpoint returns details about up to 100 Posts specified by the requested IDs.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/lookup/api-reference/get-posts) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * ids String Required. Enter up to 100 comma-separated Post IDs. (optional)
 * returns Object
 **/
exports.v1PostsGET = function(ids) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Single Post Usercontext
 * This endpoint returns details about the Post specified by the requested ID.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/lookup/api-reference/get-posts-id) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. Enter a single Post ID.
 * returns Object
 **/
exports.v1PostsIdGET = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

