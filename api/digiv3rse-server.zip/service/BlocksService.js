'use strict';


/**
 * Blocks lookup
 * Returns a list of users who are blocked by the specified user ID.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/blocks/api-reference/get-users-blocking) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The user ID whose blocked users you would like to retrieve. The user’s ID must correspond to the user ID of the authenticating user, meaning that you must pass the Access Tokens associated with the user ID when authenticating your request.
 * no response value expected for this operation
 **/
exports.v1UsersIdBlockingGET = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Block a user ID
 * Allows a user ID to block another user.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/blocks/api-reference/post-users-user_id-blocking) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * id String 
 * no response value expected for this operation
 **/
exports.v1UsersIdBlockingPOST = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Unblock a user ID
 * Allows a user ID to unblock another user.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/blocks/api-reference/delete-users-user_id-blocking) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * source_user_id String The ID of the user who wishes to unblock an account. The ID must belong to the authenticating user.  In Postman, you can leave the `source_user_id` field empty to let the collection automatically populate it with the user ID of the user in the current environment. In Postman, you can leave the `source_user_id` field empty to let the collection automatically populate it with the user ID of the user in the current environment.
 * target_user_id String The ID of the user to unblock.
 * no response value expected for this operation
 **/
exports.v1UsersSource_user_idBlockingTarget_user_idDELETE = function(source_user_id,target_user_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

