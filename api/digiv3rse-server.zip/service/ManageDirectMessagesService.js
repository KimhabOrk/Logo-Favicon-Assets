'use strict';


/**
 * Add DM to conversation
 *
 * body Object  (optional)
 * dm_conversation_id Integer The conversation ID that this message will be added to. Supports both one-to-one and group conversations. 
 * no response value expected for this operation
 **/
exports.v1Dm_conversationsDm_conversation_idMessagesPOST = function(body,dm_conversation_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * New group DM and conversation
 *
 * body Object  (optional)
 * no response value expected for this operation
 **/
exports.v1Dm_conversationsPOST = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * New 1-1 DM message
 *
 * body Object  (optional)
 * participant_id Integer The User ID of who is receiving this one-to-one Direct Message
 * no response value expected for this operation
 **/
exports.v1Dm_conversationsWithParticipant_idMessagesPOST = function(body,participant_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

