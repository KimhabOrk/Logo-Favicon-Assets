'use strict';


/**
 * List by ID
 * This endpoint returns details about the List specified by the requested ID  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/list-lookup/api-reference/get-lists-id) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The ID of the List you wish to recieve details on.
 * no response value expected for this operation
 **/
exports.v1ListsIdGET = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * User owned Lists
 * This endpoint returns details on user owned Lists specified by the requested ID  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/list-lookup/api-reference/get-users-id-owned_lists) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The ID of the user you wish to recieve details on Lists they own.
 *  String  (optional)
 * no response value expected for this operation
 **/
exports.v1UsersIdOwned_listsGET = function(id,) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

