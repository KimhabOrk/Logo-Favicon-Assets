'use strict';


/**
 * Mutes lookup
 * Returns a list of users who are muted by the specified user ID.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/mutes/api-reference/get-users-muting) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The user ID whose muted users you would like to retrieve. The user’s ID must correspond to the user ID of the authenticating user, meaning that you must pass the Access Tokens associated with the user ID when authenticating your request.
 *  String  (optional)
 * no response value expected for this operation
 **/
exports.v1UsersIdMutingGET = function(id,) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Mute a user ID
 * Allows a user ID to mute another user.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/mutes/api-reference/post-users-user_id-muting) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * id String Required. Enter a single user ID.
 * no response value expected for this operation
 **/
exports.v1UsersIdMutingPOST = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Unmute a user ID
 * Allows a user ID to unmute another user.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/users/mutes/api-reference/delete-users-user_id-muting) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * source_user_id String The ID of the user who wishes to unmute an account. The ID must belong to the authenticating user.  In Postman, you can leave the `source_user_id` field empty to let the collection automatically populate it with the user ID of the user in the current environment.
 * target_user_id String The ID of the user to unmute.
 * no response value expected for this operation
 **/
exports.v1UsersSource_user_idMutingTarget_user_idDELETE = function(source_user_id,target_user_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

