'use strict';


/**
 * List Posts lookup
 * This endpoint returns all Posts from a List specified by the requested ID  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/list-posts/api-reference/get-lists-id-posts) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The ID of the List you wish to recieve Post details on.
 *  String  (optional)
 * no response value expected for this operation
 **/
exports.v1ListsIdPostsGET = function(id,) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

