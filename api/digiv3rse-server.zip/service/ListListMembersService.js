'use strict';


/**
 * Members lookup
 * This endpoint returns member details from the List specified by the requested ID  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/list-members/api-reference/get-lists-id-members) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The ID of the List you wish to recieve member details on.
 *  String  (optional)
 * no response value expected for this operation
 **/
exports.v1ListsIdMembersGET = function(id,) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Add a member
 * Allows the authenticated user to add a member to a List they own.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/manage-lists/api-reference/post-lists-id-members) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * id String Required. The ID of the list you wish to add a member to - Authenticated user must own the list in order to add the member
 * no response value expected for this operation
 **/
exports.v1ListsIdMembersPOST = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Remove a member
 * Allows the authenticated user to remove a member from a List they own.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/manage-lists/api-reference/delete-lists-id-members-user_id) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The ID of the List you wish to remove a user from - the List must be owned by the authenticated user
 * user_id String Required. The ID of the user you wish to remove from the list
 * no response value expected for this operation
 **/
exports.v1ListsIdMembersUser_idDELETE = function(id,user_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * User memberships
 * This endpoint returns details on Lists a user is a member of specified by the requested ID  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/list-members/api-reference/get-users-id-list_memberships) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The ID of the user you wish to recieve membership details on.
 *  String  (optional)
 * no response value expected for this operation
 **/
exports.v1UsersIdList_membershipsGET = function(id,) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

