'use strict';


/**
 * Delete a Post
 * Allows an authenticated user to delete a Post.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/manage-posts/api-reference/delete-post) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String ID to of the Post you wish to delete
 * no response value expected for this operation
 **/
exports.v1PostsIdDELETE = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Create a Post
 * Allows an authenticated user to create a Post.  You can add parameters to post polls, quote Posts, Post with reply settings, and Post to Super Followers in addition to other features.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/manage-posts/api-reference/post-post) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * no response value expected for this operation
 **/
exports.v1PostsPOST = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

