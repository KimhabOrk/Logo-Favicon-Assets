'use strict';


/**
 * Stream (see description)
 * Stream, in real-time, roughly a 1% sample of all public Posts.  Please note streaming responses are currently [not supported](https://github.com/postmanlabs/postman-app-support/issues/5040) in Postman. Use this to help form your request, then click on Code > cURL. Copy the cURL command and paste in terminal to view the response.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * no response value expected for this operation
 **/
exports.v1PostsSampleStreamGET = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

