'use strict';


/**
 * Unpin a list
 * Allows the authenticated user to unpin a specified List.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/manage-lists/api-reference/delete-users-id-pinned-lists-list_id) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The ID of the authenticated user
 * list_id String Required. The ID of the List you wish to unpin
 * no response value expected for this operation
 **/
exports.v1ListsIdPinned_listsList_idDELETE = function(id,list_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * User's pinned Lists
 * This endpoint returns details on a user's pinned Lists specified by the requested ID  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/pinned-lists/api-reference/get-users-id-pinned_lists) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The user ID whose pinned Lists you would like to retrieve. The user’s ID must correspond to the user ID of the authenticating user, meaning that you must pass the Access Tokens associated with the user ID when authenticating your request.
 *  String  (optional)
 * no response value expected for this operation
 **/
exports.v1UsersIdPinned_listsGET = function(id,) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Pin a list
 * Allows the authenticated user to pin a specified List.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/manage-lists/api-reference/post-users-id-pinned-lists) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * id String Required. The ID of the authenticated user
 * no response value expected for this operation
 **/
exports.v1UsersIdPinned_listsPOST = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

