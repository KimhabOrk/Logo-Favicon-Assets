'use strict';


/**
 * Full-archive Post counts
 * Search across the complete history of public Posts matching a search query; since the first Post was created in March 2006.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/search/api-reference/get-posts-search-all) for this endpoint.  **NOTE** this endpoint requires access via the Academic Research product track  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * query String Required. Query for matching Posts. Up to 1024 characters. (optional)
 * no response value expected for this operation
 **/
exports.v1PostsCountsAllGET = function(query) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Recent Post counts
 * Search for public Posts created in the last 7 days.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/search/api-reference/get-posts-search-recent) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * query String Required. Query for matching Posts. Up to 512 characters. (optional)
 * no response value expected for this operation
 **/
exports.v1PostsCountsRecentGET = function(query) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

