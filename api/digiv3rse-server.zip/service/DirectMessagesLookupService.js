'use strict';


/**
 * Get DMs by conversation
 *
 * dm_conversation_id Integer Events are retrieved for the conversation associated with this ID. Supports both one-to-one and group conversations. 
 * dm_event.fields String Allowed values: id,text,event_type,dm_conversation_id,created_at,sender_id,attachments,participant_ids,referenced_tweets id, text, and event_type are returned by default. Comma-separated list of fields (with no spaces).  (optional)
 * post.fields String Allowed values: attachments,author_id,context_annotations,conversation_id,created_at,entities,geo,id,in_reply_to_user_id,lang,non_public_metrics,organic_metrics,possibly_sensitive,promoted_metrics,public_metrics,referenced_tweets,reply_settings,source,text,withheld Default fields: id, text, and edit_history_tweet_ids. Requires the referenced_tweets.id expansion. Comma-separated list of fields (with no spaces).  (optional)
 * expansions String Allowed values: sender_id,referenced_tweets.id,attachments.media_keys,participant_ids Comma-separated list of fields (with no spaces).  (optional)
 * no response value expected for this operation
 **/
exports.v1Dm_conversationsDm_conversation_idDm_eventsGET = function(dm_conversation_id,dm_event.fields,post.fields,expansions) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * DM events by 1-1 conversation
 *
 * participant_id Integer The User ID of who this one-to-one Direct Message is with.
 * dm_event.fields String  (optional)
 * no response value expected for this operation
 **/
exports.v1Dm_conversationsWithParticipant_idDm_eventsGET = function(participant_id,dm_event.fields) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * DM events by User
 *
 * dm_event.fields String Allowed values: id,text,event_type,dm_conversation_id,created_at,sender_id,attachments,participant_ids,referenced_tweets  id, text, and event_type are returned by default.  Comma-separated list of fields (with no spaces).  (optional)
 * event_types String Allowed values: MessageCreate,ParticipantsJoin,ParticipantsLeave  Comma-separated list of fields (with no spaces).   All event types are returned by default.  (optional)
 * user.fields String Allowed values: created_at, description, entities, id, location, name, pinned_tweet_id, profile_image_url, protected, public_metrics, url, username, verified, withheld  Default values: id,name,username  Requires the participants_ids and/or sender_id expansions.  Comma-separated list of fields (with no spaces).  (optional)
 * expansions String Allowed values: sender_id,referenced_tweets.id,attachments.media_keys,participant_ids Comma-separated list of fields (with no spaces).  (optional)
 * no response value expected for this operation
 **/
exports.v1Dm_eventsGET = function(dm_event.fields,event_types,user.fields,expansions) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

