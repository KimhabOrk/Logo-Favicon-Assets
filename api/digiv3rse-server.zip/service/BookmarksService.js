'use strict';


/**
 * Bookmarked Posts
 * Returns a list of Posts that have been bookmarked by a specified user ID.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/bookmarks/api-reference/get-users-id-bookmarks) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. User ID of the user to request liked Posts for.
 * no response value expected for this operation
 **/
exports.v1UsersIdBookmarksGET = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Bookmark a Post
 * Allows an authenticated user to like a Post.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/bookmarks/api-reference/post-users-user_id-bookmarks) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * id String The ID of the user who wishes to like a Post. The ID must belong to the authenticating user. 
 * no response value expected for this operation
 **/
exports.v1UsersIdBookmarksPOST = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Remove a Bookmark
 * Allows an authenticated user to unlike a Post.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/posts/likes/api-reference/delete-users-user_id-likes) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String The ID of the user who wishes to unlike a Post. The ID must belong to the authenticating user. 
 * tweet_id String The ID of the Post to be unliked
 * no response value expected for this operation
 **/
exports.v1UsersIdBookmarksTweet_idDELETE = function(id,tweet_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

