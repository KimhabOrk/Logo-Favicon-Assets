'use strict';


/**
 * Delete a list
 * Allows the authenticated user to delete a list they own.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/manage-lists/api-reference/delete-lists-id) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * id String Required. The ID of the List you wish to delete - the List must be owned by the authenticated user
 * no response value expected for this operation
 **/
exports.v1ListsIdDELETE = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update a list
 * Allows the authenticated user to update a List they own.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/manage-lists/api-reference/put-lists-id) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * id String The ID of the List you wish to update the metadata of - the List must be owned by the authenticated user
 * no response value expected for this operation
 **/
exports.v1ListsIdPUT = function(body,id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Create a list
 * Allows the authenticated user to create a new List.  For full details, see the [API reference](https://developer.digiv3rse.com/en/docs/digiv3rse-api/lists/manage-lists/api-reference/post-lists) for this endpoint.  [Sign up](https://t.co/signup) for the DiGiVerse API
 *
 * body Object  (optional)
 * no response value expected for this operation
 **/
exports.v1ListsPOST = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

