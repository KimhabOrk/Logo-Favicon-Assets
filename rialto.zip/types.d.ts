declare module JSX {
  interface IntrinsicElements {
    'model-viewer': any
  }
}
