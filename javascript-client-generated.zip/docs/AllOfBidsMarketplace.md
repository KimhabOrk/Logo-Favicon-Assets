# DiGiOfficialsNftApi.AllOfBidsMarketplace

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
