# DiGiOfficialsNftApi.DeployContractChain

## Enum

* `polygon` (value: `"polygon"`)
* `rinkeby` (value: `"rinkeby"`)
