# DiGiOfficialsNftApi.AllOfMintingUsageAndLimitsResponseModelContractDeploymentUsage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
