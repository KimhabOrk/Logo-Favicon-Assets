# DiGiOfficialsNftApi.SrcServiceNftsEntitiesNftDetailsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**nft** | **AllOfsrcServiceNftsEntitiesNftDetailsResponseNft** | Details of the NFT. | [optional] 
**contract** | **AllOfsrcServiceNftsEntitiesNftDetailsResponseContract** | Information of the NFT’s contract. | [optional] 
**status** | **String** | Status of the contract tokens in the metadata refresh queue. | [optional] 
**statusMessage** | **String** | Detailed description of the &#x60;&#x60;&#x60;status&#x60;&#x60;&#x60;. | [optional] 
**error** | **String** | Error response. | [optional] 

<a name="StatusEnum"></a>
## Enum: StatusEnum

* `ADDED` (value: `"ADDED"`)
* `PROCESSING` (value: `"PROCESSING"`)
* `PENDING` (value: `"PENDING"`)
* `REFRESHED_RECENTLY` (value: `"REFRESHED_RECENTLY"`)

