# DiGiOfficialsNftApi.SrcServiceMintingDeprecatedEntitiesUserMintedNftResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chain** | **AllOfsrcServiceMintingDeprecatedEntitiesUserMintedNftResponseChain** | Chain the NFT was minted on. | 
**transactionHash** | **String** | NFT minting transaction hash. | 
**contractName** | **String** | Contract name of the minted NFT. | 
**contractAddress** | **String** | Contract address of the minted NFT. | [optional] 
**tokenId** | **String** | Token ID of the minted NFT. | [optional] 
**mintedAddress** | **String** | Address where the NFT was minted. | 
**metadataIpfsUri** | **String** | Metadata IPFS URI | [optional] 
**mintedDate** | **String** | Date when the NFT was minted (UTC). | 
