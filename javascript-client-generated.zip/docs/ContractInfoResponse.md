# DiGiOfficialsNftApi.ContractInfoResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the contract. | [optional] 
**symbol** | **String** | Symbol of the contract. | [optional] 
**type** | **String** | Contract type. | [optional] 

<a name="TypeEnum"></a>
## Enum: TypeEnum

* `eRC721` (value: `"ERC721"`)
* `eRC1155` (value: `"ERC1155"`)

