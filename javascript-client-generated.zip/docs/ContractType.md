# DiGiOfficialsNftApi.ContractType

## Enum

* `eRC721` (value: `"ERC721"`)
* `eRC1155` (value: `"ERC1155"`)
* `eRC721Lazy` (value: `"ERC721_lazy"`)
* `eRC1155Lazy` (value: `"ERC1155_lazy"`)
