# DiGiOfficialsNftApi.AllOfsrcServiceTransactionsEntitiesNftContractType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
