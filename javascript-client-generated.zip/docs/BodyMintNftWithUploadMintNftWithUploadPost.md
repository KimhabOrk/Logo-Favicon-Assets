# DiGiOfficialsNftApi.BodyMintNftWithUploadMintNftWithUploadPost

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file** | **Blob** |  | 
