# DiGiOfficialsNftApi.Sales

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | Activity type. | 
**buyerAddress** | **String** | Account address of the buyer. | 
**sellerAddress** | **String** | Account address of the seller. | 
**nft** | **AllOfSalesNft** | Details of the sold NFT. | 
**quantity** | **Number** | Number of NFT units (can be more than 1 NFT for ERC1155). | [optional] 
**priceDetails** | **AllOfSalesPriceDetails** | Price details of the sale. | 
**transactionHash** | **String** | A unique 66-character identifier that is generated when a transaction is executed on the blockchain. | 
**blockHash** | **String** | The hash of the block header in which the transaction is recorded. | 
**blockNumber** | **Number** | Number of the block in which the transaction is recorded. | 
**transactionDate** | **String** | Date of the transaction (ISO). | 
**marketplace** | **AllOfSalesMarketplace** | Marketplace where the sale took place. | [optional] 

<a name="TypeEnum"></a>
## Enum: TypeEnum

* `sale` (value: `"sale"`)

