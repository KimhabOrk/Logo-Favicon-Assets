# DiGiOfficialsNftApi.Chain

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
