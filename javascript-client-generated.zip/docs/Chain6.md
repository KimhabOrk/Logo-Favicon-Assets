# DiGiOfficialsNftApi.Chain6

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
