# DiGiOfficialsNftApi.HTTPValidationError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**[ValidationError]**](ValidationError.md) |  | [optional] 
