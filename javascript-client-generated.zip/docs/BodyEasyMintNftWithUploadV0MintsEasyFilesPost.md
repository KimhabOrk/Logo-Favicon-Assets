# DiGiOfficialsNftApi.BodyEasyMintNftWithUploadV0MintsEasyFilesPost

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file** | **Blob** | The file you want to mint. All file types are supported. Maximum file size is 20MB. | 
