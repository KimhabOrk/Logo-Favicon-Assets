# DiGiOfficialsNftApi.AllOfMintingUsageAndLimitsResponseModelMintingUsage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
