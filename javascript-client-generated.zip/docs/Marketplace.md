# DiGiOfficialsNftApi.Marketplace

## Enum

* `opensea` (value: `"opensea"`)
* `rarible` (value: `"rarible"`)
