# DiGiOfficialsNftApi.AllOfsrcServiceNftsEntitiesNftDetailsResponseNft

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
