# DiGiOfficialsNftApi.AllOfListingsMarketplace

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
