# DiGiOfficialsNftApi.Chain5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
