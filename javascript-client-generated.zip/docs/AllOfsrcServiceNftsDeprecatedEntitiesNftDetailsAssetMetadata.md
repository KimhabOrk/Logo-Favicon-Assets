# DiGiOfficialsNftApi.AllOfsrcServiceNftsDeprecatedEntitiesNftDetailsAssetMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
