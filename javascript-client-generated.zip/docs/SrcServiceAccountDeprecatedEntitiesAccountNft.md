# DiGiOfficialsNftApi.SrcServiceAccountDeprecatedEntitiesAccountNft

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contractAddress** | **String** | The contract address of the NFT. | 
**tokenId** | **String** | A unique &#x60;&#x60;&#x60;uint256&#x60;&#x60;&#x60; ID inside the contract. The contract address and token ID pair is a globally unique and fully-qualified identifier for a specific NFT on chain. | 
**name** | **String** | Name of the NFT. | [optional] 
**description** | **String** | Description of the NFT. | [optional] 
**assetUrl** | **String** | NFT file URL where it is hosted. | [optional] 
**creatorAddress** | **String** | NFT creator address. | [optional] 
**metadata** | **Object** | NFT metadata downloaded and parsed from the contract token URI. It usually includes the name, description and attributes along with any other data added by the creator. | [optional] 
