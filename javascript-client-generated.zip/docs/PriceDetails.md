# DiGiOfficialsNftApi.PriceDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**assetType** | **String** | Type of the asset the NFT is traded for. | [optional] 
**contractAddress** | **String** | Contract address (for &#x60;ERC20&#x60;). | [optional] 
**price** | **Number** | Price in &#x60;asset_type&#x60;- &#x60;ETH&#x60; or &#x60;ERC20&#x60;. | [optional] 
**priceUsd** | **Number** | Price in USD. | [optional] 

<a name="AssetTypeEnum"></a>
## Enum: AssetTypeEnum

* `ETH` (value: `"ETH"`)
* `eRC20` (value: `"ERC20"`)

