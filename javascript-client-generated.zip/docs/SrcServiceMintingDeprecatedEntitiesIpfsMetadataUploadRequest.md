# DiGiOfficialsNftApi.SrcServiceMintingDeprecatedEntitiesIpfsMetadataUploadRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of NFT. | 
**description** | **String** | Description of NFT. | 
**fileUri** | **String** | URL of the file that you wish to link with the metadata and turn into an NFT. | 
**attributes** | [**[MetadataAttribute]**](MetadataAttribute.md) | Optional list of NFT attributes. | [optional] 
