# DiGiOfficialsNftApi.SortOrder1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
