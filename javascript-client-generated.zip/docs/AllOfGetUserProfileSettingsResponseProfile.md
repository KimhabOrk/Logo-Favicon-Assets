# DiGiOfficialsNftApi.AllOfGetUserProfileSettingsResponseProfile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
