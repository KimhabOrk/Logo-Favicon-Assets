# DiGiOfficialsNftApi.AllOfsrcServiceNftsEntitiesNftFileInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
