# DiGiOfficialsNftApi.AllOfSalesNft

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
