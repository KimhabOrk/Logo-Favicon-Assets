# DiGiOfficialsNftApi.DeployContractRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chain** | **AllOfDeployContractRequestChain** | Blockchain to deploy the contract to. | 
**contractName** | **String** | Name of the NFT contract | 
**contractSymbol** | **String** | Symbol of the NFT contract | 
