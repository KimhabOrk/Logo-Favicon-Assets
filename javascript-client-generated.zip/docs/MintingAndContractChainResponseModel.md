# DiGiOfficialsNftApi.MintingAndContractChainResponseModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**polygon** | **AllOfMintingAndContractChainResponseModelPolygon** | Your minting and contract deployment usage and limits on Polygon. | 
**rinkeby** | **AllOfMintingAndContractChainResponseModelRinkeby** | Your minting and contract deployment usage and limits on Rinkeby. | 
