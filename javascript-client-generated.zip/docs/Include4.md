# DiGiOfficialsNftApi.Include4

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
