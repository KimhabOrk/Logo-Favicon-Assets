# DiGiOfficialsNftApi.Chain3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
