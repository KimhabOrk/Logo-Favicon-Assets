# DiGiOfficialsNftApi.AnyOfTransactionsByContractResponseTransactionsItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
