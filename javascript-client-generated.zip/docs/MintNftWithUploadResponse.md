# DiGiOfficialsNftApi.MintNftWithUploadResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**chain** | **String** | Blockchain the NFT was minted on. | [optional] 
**contractAddress** | **String** | The contract address where the NFT was minted. | [optional] 
**transactionHash** | **String** | The transaction hash which is returned by the blockchain after minting. | [optional] 
**transactionExternalUrl** | **String** | Transaction URL in an external blockchain explorer. | [optional] 
**mintToAddress** | **String** | Account address where the NFT was sent. | [optional] 
**name** | **String** | Name of the NFT. | [optional] 
**description** | **String** | Description of the NFT. | [optional] 
**error** | **String** | Error response. | [optional] 

<a name="ChainEnum"></a>
## Enum: ChainEnum

* `polygon` (value: `"polygon"`)
* `rinkeby` (value: `"rinkeby"`)

