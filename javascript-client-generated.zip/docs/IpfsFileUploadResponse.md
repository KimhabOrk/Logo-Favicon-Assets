# DiGiOfficialsNftApi.IpfsFileUploadResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**ipfsUrl** | **String** | IPFS URL of the uploaded file. | [optional] 
**fileName** | **String** | Name of the uploaded file. | [optional] 
**contentType** | **String** | Content type (MIME type / media type) of the uploaded file (e.g. image/jpeg). | [optional] 
**fileSize** | **Number** | Size of the uploaded file in bytes. | [optional] 
**fileSizeMb** | **Number** | Size of the uploaded file in MB. | [optional] 
**error** | **String** | Error response. | [optional] 
