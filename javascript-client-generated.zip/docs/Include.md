# DiGiOfficialsNftApi.Include

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
