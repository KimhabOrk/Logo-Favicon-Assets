# DiGiOfficialsNftApi.AllOfMintingUsageAndLimitsResponseModelMintingLimits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
