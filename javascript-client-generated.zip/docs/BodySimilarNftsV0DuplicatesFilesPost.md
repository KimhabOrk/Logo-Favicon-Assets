# DiGiOfficialsNftApi.BodySimilarNftsV0DuplicatesFilesPost

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file** | **Blob** | Input image which will be analyzed to find duplicates. Supports .JPG, .JPEG, .PNG, .WebP, .PPM, .BMP, .PGM, .TIF, .TIFF, file formats. | 
