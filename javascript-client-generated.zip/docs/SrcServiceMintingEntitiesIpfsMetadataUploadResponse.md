# DiGiOfficialsNftApi.SrcServiceMintingEntitiesIpfsMetadataUploadResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**metadataUri** | **String** | Uploaded metadata URI (also known as token URI) which you can use in [Customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting). | [optional] 
**name** | **String** | Name of the NFT. | [optional] 
**description** | **String** | Description of the NFT. | [optional] 
**fileUrl** | **String** | URL of the file that is linked with the metadata and can be turned into an NFT. | [optional] 
**externalUrl** | **String** | URL that will appear below the NFT on some of the NFT marketplaces such as OpenSea. | [optional] 
**animationUrl** | **String** | URL to a multimedia attachment. | [optional] 
**customFields** | **Object** | Custom fields added to the metadata. | [optional] 
**attributes** | [**[MetadataAttribute]**](MetadataAttribute.md) | NFT attributes. | [optional] 
**error** | **String** | Error response. | [optional] 
