# DiGiOfficialsNftApi.AllOfsrcServiceNftsEntitiesNftDetailsFileInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
