# DiGiOfficialsNftApi.AnyOfMetadataAttributeValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
