# DiGiOfficialsNftApi.SrcServiceMintingEntitiesGetUserProfileMintedNftsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**total** | **Number** | Total number of NFTs minted. | [optional] 
**mintedNfts** | [**[SrcServiceMintingEntitiesUserMintedNftResponse]**](SrcServiceMintingEntitiesUserMintedNftResponse.md) | Details of the NFTs minted by you. | [optional] 
**error** | **String** | Error response. | [optional] 
