# DiGiOfficialsNftApi.SortOrder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
