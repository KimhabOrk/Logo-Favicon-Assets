# DiGiOfficialsNftApi.AllOfsrcServiceNftsEntitiesNftContract

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
