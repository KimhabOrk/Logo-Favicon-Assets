# DiGiOfficialsNftApi.SearchRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query** | **String** | Search query | 
**pageNumber** | **Number** | The page number of the results to return. The first page is 1. | [optional] [default to 1]
**pageSize** | **Number** | The number of results returned per page. Limit can range between 1 and 50, and the default is 50. | [optional] [default to 50]
