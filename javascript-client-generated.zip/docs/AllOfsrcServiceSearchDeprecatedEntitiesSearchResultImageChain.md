# DiGiOfficialsNftApi.AllOfsrcServiceSearchDeprecatedEntitiesSearchResultImageChain

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
