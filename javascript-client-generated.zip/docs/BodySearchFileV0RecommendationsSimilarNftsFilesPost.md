# DiGiOfficialsNftApi.BodySearchFileV0RecommendationsSimilarNftsFilesPost

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file** | **Blob** | Input image based on which visually and contextually similar NFTs will be recommended. Supports .JPG, .JPEG, .PNG, .WebP file formats. | 
