# DiGiOfficialsNftApi.AllOfsrcServiceNftsEntitiesNftDetailsResponseContract

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
