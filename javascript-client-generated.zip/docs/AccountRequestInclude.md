# DiGiOfficialsNftApi.AccountRequestInclude

## Enum

* `_default` (value: `"default"`)
* `metadata` (value: `"metadata"`)
