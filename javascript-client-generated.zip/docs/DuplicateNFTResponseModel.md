# DiGiOfficialsNftApi.DuplicateNFTResponseModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contractAddress** | **String** | Contract address of the NFT. | 
**tokenId** | **String** | A unique &#x60;&#x60;&#x60;uint256&#x60;&#x60;&#x60; ID inside the contract. The contract address and token ID pair is a globally unique and fully-qualified identifier for a specific NFT on chain. | 
**chain** | **String** | Blockchain where the NFT has been minted. | 
**similarity** | **Number** | Similarity of the input image to the NFT (0 to 1). | 
**fileUrl** | **String** | File (image, video, etc) url of the NFT. | [optional] 
**cachedFileUrl** | **String** | Cached file (image, video, etc) in DiGiOfficial&#x27;s NFT&#x27;s cloud with no access restrictions and without IPFS issues. | [optional] 
**metadataUrl** | **String** | Metadata URL inside the contract for a given token, also known as the token URI. For ERC-721 it is the token_uri() function and for ERC-1155 it is the uri() function in the smart contract. | [optional] 
**metadata** | **Object** | Raw NFT metadata downloaded from the metadata_url i.e. token URI. It usually includes the name, description and attributes along with any other data added by the creator. | [optional] 
**mintDate** | **String** | Date when the NFT was minted (ISO). | [optional] 

<a name="ChainEnum"></a>
## Enum: ChainEnum

* `ethereum` (value: `"ethereum"`)
* `polygon` (value: `"polygon"`)

