# DiGiOfficialsNftApi.Chain2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
