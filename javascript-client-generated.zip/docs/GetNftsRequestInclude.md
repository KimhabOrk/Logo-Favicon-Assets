# DiGiOfficialsNftApi.GetNftsRequestInclude

## Enum

* `_default` (value: `"default"`)
* `metadata` (value: `"metadata"`)
* `fileInformation` (value: `"file_information"`)
* `contractInformation` (value: `"contract_information"`)
* `all` (value: `"all"`)
