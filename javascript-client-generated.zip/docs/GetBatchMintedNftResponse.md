# DiGiOfficialsNftApi.GetBatchMintedNftResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**chain** | **String** | Blockchain the NFT was minted on. | [optional] 
**contractAddress** | **String** | NFT contract address which has been successfully deployed to the blockchain. | [optional] 
**tokenIds** | **[String]** | A unique &#x60;&#x60;&#x60;uint256&#x60;&#x60;&#x60; IDs list inside the contract. The contract address and token ID pair is a globally unique and fully-qualified identifier for a specific NFT on chain. | [optional] 
**error** | **String** | Error response. | [optional] 

<a name="ChainEnum"></a>
## Enum: ChainEnum

* `polygon` (value: `"polygon"`)
* `rinkeby` (value: `"rinkeby"`)

