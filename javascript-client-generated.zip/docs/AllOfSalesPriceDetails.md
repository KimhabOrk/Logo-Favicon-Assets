# DiGiOfficialsNftApi.AllOfSalesPriceDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
