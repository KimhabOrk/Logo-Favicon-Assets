# DiGiOfficialsNftApi.AllOfMintingUsageAndLimitsResponseModelContractDeploymentLimits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
