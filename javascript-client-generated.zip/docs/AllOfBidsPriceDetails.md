# DiGiOfficialsNftApi.AllOfBidsPriceDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
