# DiGiOfficialsNftApi.CollectionStatsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**statistics** | **AllOfCollectionStatsResponseStatistics** | In-depth statistics of the queried NFT contract. | [optional] 
**error** | **String** | Error response. | [optional] 
