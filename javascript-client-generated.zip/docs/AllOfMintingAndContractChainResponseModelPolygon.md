# DiGiOfficialsNftApi.AllOfMintingAndContractChainResponseModelPolygon

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
