# DiGiOfficialsNftApi.NFTDataLimitsResponseModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nftDataRequestsLimitDaily** | **Number** | Number of requests allowed per day. | 
**nftDataRequestsLimitSecond** | **Number** | Number of requests allowed per second. | 
