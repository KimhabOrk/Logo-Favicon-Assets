# DiGiOfficialsNftApi.AllOfListingsPriceDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
