# DiGiOfficialsNftApi.Listings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | Activity type. | 
**listerAddress** | **String** | Account address of the lister. | 
**nft** | **AllOfListingsNft** | Details of the listed NFT. | 
**quantity** | **Number** | Number of NFTs listed (can be more than 1 NFT for ERC1155). | [optional] 
**priceDetails** | **AllOfListingsPriceDetails** | Price details of the listing. | 
**transactionHash** | **String** | A unique 66-character identifier that is generated when a transaction is executed on the blockchain. | [optional] 
**blockHash** | **String** | The hash of the block header in which the transaction is recorded. | [optional] 
**blockNumber** | **Number** | Number of the block in which the transaction is recorded | [optional] 
**transactionDate** | **String** | Date of the transaction (ISO). | 
**marketplace** | **AllOfListingsMarketplace** | Marketplace where the NFT was listed. | [optional] 

<a name="TypeEnum"></a>
## Enum: TypeEnum

* `list` (value: `"list"`)
* `cancelList` (value: `"cancel_list"`)

