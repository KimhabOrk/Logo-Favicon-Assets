# DiGiOfficialsNftApi.BodyIpfsUploadFileV0FilesPost

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file** | **Blob** | The file to upload to IPFS. All file types are supported. Maximum file size is 20MB. | 
