# DiGiOfficialsNftApi.ContentIdResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**isSimilar** | **Boolean** | Returns true if a match is found, false otherwise. | [optional] 
**similarNfts** | [**[DuplicateNFTResponseModel]**](DuplicateNFTResponseModel.md) | Details of matching NFTs if found. | 
**error** | **String** | Error response. | [optional] 
