# DiGiOfficialsNftApi.GetUserProfileSettingsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**profile** | **AllOfGetUserProfileSettingsResponseProfile** | Your user profile. | [optional] 
**subscriptionPeriod** | **AllOfGetUserProfileSettingsResponseSubscriptionPeriod** | Your subscription period. | [optional] 
**nftDataLimits** | **AllOfGetUserProfileSettingsResponseNftDataLimits** | Your NFT Data usage limits. | [optional] 
**mintingUsageAndLimits** | **AllOfGetUserProfileSettingsResponseMintingUsageAndLimits** | Your minting and contract deployment usage and limits. | [optional] 
**error** | **String** | Error response. | [optional] 
