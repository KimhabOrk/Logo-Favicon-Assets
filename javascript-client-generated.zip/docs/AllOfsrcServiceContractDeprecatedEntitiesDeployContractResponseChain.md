# DiGiOfficialsNftApi.AllOfsrcServiceContractDeprecatedEntitiesDeployContractResponseChain

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
