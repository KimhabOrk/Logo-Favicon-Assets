# DiGiOfficialsNftApi.GetDeployedContractResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**chain** | **String** | Blockchain where the contract has been created. | [optional] 
**contractAddress** | **String** | NFT contract address which has been successfully deployed to the blockchain. | [optional] 
**transactionHash** | **String** | Transaction hash generated during the execution of deploying the contract. | [optional] 
**error** | **String** | Error response. | [optional] 

<a name="ChainEnum"></a>
## Enum: ChainEnum

* `polygon` (value: `"polygon"`)
* `rinkeby` (value: `"rinkeby"`)

