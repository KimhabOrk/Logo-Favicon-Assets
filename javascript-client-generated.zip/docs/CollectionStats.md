# DiGiOfficialsNftApi.CollectionStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**oneDayVolume** | **Number** | Volume of sales in the last 24 hours in ETH. | [optional] 
**oneDayChange** | **Number** | Change in volume of sales in the last 24 hours in ETH. | [optional] 
**oneDaySales** | **Number** | Number of sales in the last 24 hours. | [optional] 
**oneDayAveragePrice** | **Number** | Average price in the last 24 hours in ETH. | [optional] 
**sevenDayVolume** | **Number** | Volume of sales in the last 7 days in ETH. | [optional] 
**sevenDayChange** | **Number** | Change in volume of sales in the last 7 days in ETH. | [optional] 
**sevenDaySales** | **Number** | Number of sales in the last 7 days. | [optional] 
**sevenDayAveragePrice** | **Number** | Average price in the last 7 days in ETH. | [optional] 
**thirtyDayVolume** | **Number** | Volume of sales in the last 30 days in ETH. | [optional] 
**thirtyDayChange** | **Number** | Change in volume of sales in the last 30 days in ETH. | [optional] 
**thirtyDaySales** | **Number** | Number of sales in the last 30 days. | [optional] 
**thirtyDayAveragePrice** | **Number** | Average price in the last 30 days in ETH. | [optional] 
**totalVolume** | **Number** | Total volume of sales in ETH. | [optional] 
**totalSales** | **Number** | Total number of sales. | [optional] 
**totalSupply** | **Number** | Total number of NFTs in supply. | [optional] 
**totalMinted** | **Number** | Total number of NFTs minted. | [optional] 
**numOwners** | **Number** | Total number of owners. | [optional] 
**averagePrice** | **Number** | Average price of the collection since inception in ETH. | [optional] 
**marketCap** | **Number** | Market cap of the collection in ETH. | [optional] 
**floorPrice** | **Number** | Floor price of the collection in ETH. | [optional] 
