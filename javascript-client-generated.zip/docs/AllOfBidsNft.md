# DiGiOfficialsNftApi.AllOfBidsNft

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
