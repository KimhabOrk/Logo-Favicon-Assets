# DiGiOfficialsNftApi.SrcServiceNftsDeprecatedEntitiesNftDetailsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**nft** | [**SrcServiceNftsDeprecatedEntitiesNftDetails**](SrcServiceNftsDeprecatedEntitiesNftDetails.md) |  | [optional] 
**error** | **String** | Error response. | [optional] 
