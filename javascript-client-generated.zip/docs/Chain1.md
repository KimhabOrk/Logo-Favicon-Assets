# DiGiOfficialsNftApi.Chain1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
