# DiGiOfficialsNftApi.AllOfContractNftFileInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
