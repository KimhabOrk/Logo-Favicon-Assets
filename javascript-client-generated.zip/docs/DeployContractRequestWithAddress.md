# DiGiOfficialsNftApi.DeployContractRequestWithAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chain** | **String** | Blockchain to deploy the contract to. | 
**name** | **String** | Name of the NFT contract. | 
**symbol** | **String** | Symbol of the NFT contract. | 
**ownerAddress** | **String** | The contract owner address. If you wish to own the contract, then set it as your wallet address. | 
**type** | **String** | Type of deployed contract (erc721/erc1155). Default type is erc721. | [optional] 
**metadataUpdatable** | **Boolean** | If &#x60;&#x60;&#x60;true&#x60;&#x60;&#x60;, the metadata of the NFTs minted in the specified contract can be updated after minting (token URIs are not frozen on the contract level). This is useful for creating dynamic NFTs or revealing the NFTs after the drop. If &#x60;&#x60;&#x60;false&#x60;&#x60;&#x60;, all the NFTs minted in this contract are frozen by default which means token URIs are non-updatable. Metadata may also be frozen after deploying the contract on a contract and token level (see [Update a deployed contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjU2NTIyMTM-update-a-deployed-contract) &amp; [Update a minted NFT](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjU2NTIyMTg-update-a-minted-nft)). | [optional] 
**baseUri** | **String** | Optional metadata base URI for tokens. If you specify this, then NFTs minted in this contract will have metadata format of &#x60;&#x60;&#x60;base_uri&#x60;&#x60;&#x60; + &#x60;&#x60;&#x60;metadata_uri&#x60;&#x60;&#x60;. This is useful for creating dynamic NFTs or revealing the NFTs after the drop. &#x60;&#x60;&#x60;base_uri&#x60;&#x60;&#x60; can be changed with [Update a deployed contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjU2NTIyMTM-update-a-deployed-contract) only if &#x60;&#x60;&#x60;metadata_updatable&#x60;&#x60;&#x60; is &#x60;&#x60;&#x60;true&#x60;&#x60;&#x60; and metadata hasn’t been frozen on the contract level. If an NFT’s metadata is frozen on the token level in [Update a minted NFT](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjU2NTIyMTg-update-a-minted-nft) the &#x60;&#x60;&#x60;base_uri&#x60;&#x60;&#x60; can still be updated. | [optional] 

<a name="ChainEnum"></a>
## Enum: ChainEnum

* `polygon` (value: `"polygon"`)
* `rinkeby` (value: `"rinkeby"`)


<a name="TypeEnum"></a>
## Enum: TypeEnum

* `erc721` (value: `"erc721"`)
* `erc1155` (value: `"erc1155"`)

