# DiGiOfficialsNftApi.AccountRequestSupportedChain

## Enum

* `ethereum` (value: `"ethereum"`)
* `polygon` (value: `"polygon"`)
* `tezos` (value: `"tezos"`)
