# DiGiOfficialsNftApi.NftsRequestChain

## Enum

* `ethereum` (value: `"ethereum"`)
* `rinkeby` (value: `"rinkeby"`)
* `polygon` (value: `"polygon"`)
* `tezos` (value: `"tezos"`)
