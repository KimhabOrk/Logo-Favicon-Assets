# DiGiOfficialsNftApi.MintNftRequestChain

## Enum

* `polygon` (value: `"polygon"`)
* `rinkeby` (value: `"rinkeby"`)
