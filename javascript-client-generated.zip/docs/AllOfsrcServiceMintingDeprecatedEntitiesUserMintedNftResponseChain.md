# DiGiOfficialsNftApi.AllOfsrcServiceMintingDeprecatedEntitiesUserMintedNftResponseChain

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
