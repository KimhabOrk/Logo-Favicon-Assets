# DiGiOfficialsNftApi.MintBatchNftRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chain** | **String** | Blockchain where to mint the NFT. | 
**contractAddress** | **String** | The NFT will be minted inside this contract. It must be your own contract. If you don’t have one, see [Deploy an NFT contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzU-deploy-an-nft-contract). | 
**tokens** | [**[MintBatchTokenItem]**](MintBatchTokenItem.md) | List of tokens to be minted. Each record contains mint_to_address, token ID, metadata_uri and quantity. Maximum length is 50. | 

<a name="ChainEnum"></a>
## Enum: ChainEnum

* `polygon` (value: `"polygon"`)
* `rinkeby` (value: `"rinkeby"`)

