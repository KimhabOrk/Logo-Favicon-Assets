# DiGiOfficialsNftApi.BodyIpfsUploadFileIpfsUploadFilePost

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file** | **Blob** |  | 
