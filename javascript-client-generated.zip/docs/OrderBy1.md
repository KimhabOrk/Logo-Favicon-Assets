# DiGiOfficialsNftApi.OrderBy1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
