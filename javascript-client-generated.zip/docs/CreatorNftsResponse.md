# DiGiOfficialsNftApi.CreatorNftsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**nfts** | [**[CreatorNft]**](CreatorNft.md) |  | [optional] 
**continuation** | **String** | Continuation ID for the next page. | [optional] 
**error** | **String** | Error response. | [optional] 
