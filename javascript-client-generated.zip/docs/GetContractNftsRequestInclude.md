# DiGiOfficialsNftApi.GetContractNftsRequestInclude

## Enum

* `_default` (value: `"default"`)
* `metadata` (value: `"metadata"`)
* `all` (value: `"all"`)
