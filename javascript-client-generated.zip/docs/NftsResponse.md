# DiGiOfficialsNftApi.NftsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**nfts** | [**[SrcServiceNftsEntitiesNft]**](SrcServiceNftsEntitiesNft.md) | Details of the NFTs. | [optional] 
**continuation** | **String** | Continuation ID for next page. | [optional] 
**error** | **String** | Error response. | [optional] 
