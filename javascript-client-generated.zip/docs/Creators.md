# DiGiOfficialsNftApi.Creators

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountAddress** | **String** | Account address of the creator. | 
**creatorShare** | **Number** | Creator share of the NFT (Range: 1-10000 i.e., 0.01%-100%). If an NFT has more than one creator, this tells how the creatorship is shared among the creators. | 
