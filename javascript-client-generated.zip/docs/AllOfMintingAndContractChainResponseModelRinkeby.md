# DiGiOfficialsNftApi.AllOfMintingAndContractChainResponseModelRinkeby

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
