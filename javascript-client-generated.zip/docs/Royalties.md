# DiGiOfficialsNftApi.Royalties

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountAddress** | **String** | Account address where royalty is paid. | 
**royaltyShare** | **Number** | Royalty share (Range: 1-100000 i.e., 0.01%-100%). | 
