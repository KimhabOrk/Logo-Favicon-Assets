# DiGiOfficialsNftApi.NftsRequestSupportedChain

## Enum

* `ethereum` (value: `"ethereum"`)
* `polygon` (value: `"polygon"`)
