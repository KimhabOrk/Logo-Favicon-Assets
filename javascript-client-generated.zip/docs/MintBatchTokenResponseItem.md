# DiGiOfficialsNftApi.MintBatchTokenResponseItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mintToAddress** | **String** | Account address where the NFTs were minted. | 
**tokenId** | **String** | Token ID of the NFTs. | 
**metadataUri** | **String** | Metadata URI linked with the NFTs. | 
**quantity** | **String** | The quantity of the NFTs. | 
