# DiGiOfficialsNftApi.MintNftRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chain** | **String** | Blockchain where to mint the NFT. | 
**contractAddress** | **String** | The NFT will be minted inside this contract. It must be your own contract. If you don’t have one, see [Deploy an NFT contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzU-deploy-an-nft-contract). | 
**metadataUri** | **String** | Metadata URI which will be linked with your NFT. If you don&#x27;t have one, see [Upload metadata to IPFS](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzc-upload-metadata-to-ipfs). | 
**mintToAddress** | **String** | Account address where the NFT will be sent. For example, your Metamask wallet address if you wish to send it to yourself. | 
**tokenId** | **String** | Customizable token ID for the NFT. Maximum length is 76 digit number (2^256 - 1). | [optional] 

<a name="ChainEnum"></a>
## Enum: ChainEnum

* `polygon` (value: `"polygon"`)
* `rinkeby` (value: `"rinkeby"`)

