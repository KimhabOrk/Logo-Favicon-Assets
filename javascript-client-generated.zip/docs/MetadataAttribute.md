# DiGiOfficialsNftApi.MetadataAttribute

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**traitType** | **String** | Trait name. | 
**value** | **AnyOfMetadataAttributeValue** |  | 
**maxValue** | **Number** | Maximum value for a numeric value. | [optional] 
**displayType** | **String** | Display type of the attribute (None for string values). | [optional] 

<a name="DisplayTypeEnum"></a>
## Enum: DisplayTypeEnum

* `boostNumber` (value: `"boost_number"`)
* `boostPercentage` (value: `"boost_percentage"`)
* `_number` (value: `"number"`)
* `_date` (value: `"date"`)

