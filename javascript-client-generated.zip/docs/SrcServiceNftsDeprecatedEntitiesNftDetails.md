# DiGiOfficialsNftApi.SrcServiceNftsDeprecatedEntitiesNftDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contractAddress** | **String** | The contract address of the NFT. | 
**tokenId** | **String** | A unique &#x60;&#x60;&#x60;uint256&#x60;&#x60;&#x60; ID inside the contract. The contract address and token ID pair is a globally unique and fully-qualified identifier for a specific NFT on chain. | 
**tokenUri** | **String** | Token URI (For ERC-721 it is the token_uri() function and ERC-1155 it is the uri() function in the smart contract). | [optional] 
**metadata** | **Object** | NFT metadata downloaded and parsed from the contract token URI. It usually includes the name, description and attributes along with any other data added by the creator. | [optional] 
**assetMetadata** | **AllOfsrcServiceNftsDeprecatedEntitiesNftDetailsAssetMetadata** | Extra information of the file inside the NFT. | [optional] 
**imageUrl** | **String** | Original Image URL. | [optional] 
**cachedImageUrl** | **String** | Cached image in DiGiOfficial&#x27;s NFT&#x27;s cloud with no access restrictions and without IPFS issues. | [optional] 
**mintDate** | **String** | Date when the NFT was minted. | [optional] 
