# DiGiOfficialsNftApi.AnyOfTransactionsByTokenResponseTransactionsItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
