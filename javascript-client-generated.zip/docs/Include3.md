# DiGiOfficialsNftApi.Include3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
