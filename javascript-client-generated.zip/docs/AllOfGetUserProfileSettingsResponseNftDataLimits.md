# DiGiOfficialsNftApi.AllOfGetUserProfileSettingsResponseNftDataLimits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
