# DiGiOfficialsNftApi.GetUserProfileContractsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**contracts** | [**[UserProfileContractDetails]**](UserProfileContractDetails.md) | Details of the deployed contracts. | [optional] 
**error** | **String** | Error response. | [optional] 
