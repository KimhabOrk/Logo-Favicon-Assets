# DiGiOfficialsNftApi.MintingUsageAndLimitsResponseModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mintingUsage** | **AllOfMintingUsageAndLimitsResponseModelMintingUsage** | Your minting usage. | [optional] 
**mintingLimits** | **AllOfMintingUsageAndLimitsResponseModelMintingLimits** | Your minting limits. | [optional] 
**contractDeploymentUsage** | **AllOfMintingUsageAndLimitsResponseModelContractDeploymentUsage** | Your contract deployment usage. | [optional] 
**contractDeploymentLimits** | **AllOfMintingUsageAndLimitsResponseModelContractDeploymentLimits** | Your contract deployment limits. | [optional] 
