# DiGiOfficialsNftApi.AllOfListingsNft

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
