# DiGiOfficialsNftApi.BodySearchFileVisualSearchByFilePost

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file** | **Blob** |  | 
