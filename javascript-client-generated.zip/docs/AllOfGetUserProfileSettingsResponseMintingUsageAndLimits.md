# DiGiOfficialsNftApi.AllOfGetUserProfileSettingsResponseMintingUsageAndLimits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
