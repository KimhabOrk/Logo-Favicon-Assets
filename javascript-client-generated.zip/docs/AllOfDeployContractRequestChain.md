# DiGiOfficialsNftApi.AllOfDeployContractRequestChain

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
