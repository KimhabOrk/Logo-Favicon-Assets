# DiGiOfficialsNftApi.SrcServiceMintingEntitiesUserMintedNftResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chain** | **String** | Blockchain the NFT was minted on. | 
**transactionHash** | **String** | The transaction hash which is returned by the blockchain after minting. | 
**contractName** | **String** | Contract name of the minted NFT. | 
**contractAddress** | **String** | Contract address of the minted NFT. | [optional] 
**type** | **String** | Contract type (erc721 or erc1155). | 
**tokenId** | **String** | A unique &#x60;&#x60;&#x60;uint256&#x60;&#x60;&#x60; ID inside the contract. The contract address and token ID pair is a globally unique and fully-qualified identifier for a specific NFT on chain. | [optional] 
**mintToAddress** | **String** | Account address where the NFT was sent. | 
**metadataUri** | **String** | IPFS URI containing the metadata linked with the minted NFT. | [optional] 
**quantity** | **String** | Quantity of minted tokens. For erc721 contract type it&#x27;s always 1. | 
**metadataFrozen** | **Boolean** | If &#x60;&#x60;&#x60;true&#x60;&#x60;&#x60; than the metadata can not be updated. | 
**mintDate** | **String** | Date when the NFT was minted (ISO). | 

<a name="ChainEnum"></a>
## Enum: ChainEnum

* `polygon` (value: `"polygon"`)
* `rinkeby` (value: `"rinkeby"`)

