# DiGiOfficialsNftApi.MintBatchTokenItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mintToAddress** | **String** | Account address where the NFTs will be sent. For example, your Metamask wallet address if you wish to send them to yourself. | 
**tokenId** | **String** | Customizable token ID for the NFTs. Maximum length is 76 digit number (2^256 - 1). | 
**metadataUri** | **String** | Metadata URI which will be linked with your NFTs. If you don&#x27;t have one, see [Upload metadata to IPFS](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzc-upload-metadata-to-ipfs). | 
**quantity** | **String** | The quantity of the NFTs. Maximum quantity is 76 digit integer (2^256 - 1) | 
