# DiGiOfficialsNftApi.AllOfSalesMarketplace

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
