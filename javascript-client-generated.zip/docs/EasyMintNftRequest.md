# DiGiOfficialsNftApi.EasyMintNftRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chain** | **String** | Blockchain to mint the NFT on. | 
**name** | **String** | Name of the NFT. | 
**description** | **String** | Text description of the NFT which will be seen on NFT marketplaces, etc. | 
**fileUrl** | **String** | URL that points to the image/video or any other file format as long as it returns a Content-Length and Content-Type header or contains the file extension. HTML files are not supported. | 
**mintToAddress** | **String** | Account address where the NFT will be sent. For example, your Metamask wallet address if you wish to send it to yourself. | 

<a name="ChainEnum"></a>
## Enum: ChainEnum

* `polygon` (value: `"polygon"`)
* `rinkeby` (value: `"rinkeby"`)

