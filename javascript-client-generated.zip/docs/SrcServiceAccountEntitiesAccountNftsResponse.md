# DiGiOfficialsNftApi.SrcServiceAccountEntitiesAccountNftsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**nfts** | [**[SrcServiceAccountEntitiesAccountNft]**](SrcServiceAccountEntitiesAccountNft.md) |  | [optional] 
**total** | **Number** | Total number of NFTs owned by the address. | [optional] 
**continuation** | **String** | Continuation ID for next page. | [optional] [default to &#x27;&#x27;]
**error** | **String** | Error response. | [optional] 
