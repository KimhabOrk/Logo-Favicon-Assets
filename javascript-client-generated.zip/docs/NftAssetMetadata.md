# DiGiOfficialsNftApi.NftAssetMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**height** | **Number** | Image height in pixels. | 
**width** | **Number** | Image width in pixels. | 
**fileSize** | **Number** | File size in bytes. | 
