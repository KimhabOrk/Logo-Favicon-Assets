# DiGiOfficialsNftApi.SrcServiceContractEntitiesDeployContractResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**chain** | **String** | Blockchain where the contract has been created. | [optional] 
**transactionHash** | **String** | Deployed contract transaction hash which is a unique string of characters that is given to every transaction that is added to the blockchain. | [optional] 
**transactionExternalUrl** | **String** | Transaction URL in an external blockchain explorer. | [optional] 
**ownerAddress** | **String** | Owner address of the deployed NFT contract. | [optional] 
**name** | **String** | Name of the deployed NFT contract. | [optional] 
**symbol** | **String** | Symbol of the deployed NFT contract. | [optional] 
**error** | **String** | Error response. | [optional] 

<a name="ChainEnum"></a>
## Enum: ChainEnum

* `polygon` (value: `"polygon"`)
* `rinkeby` (value: `"rinkeby"`)

