# DiGiOfficialsNftApi.AllOfContractNftsResponseContract

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
