# DiGiOfficialsNftApi.SrcServiceContractDeprecatedEntitiesDeployContractResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**chain** | **AllOfsrcServiceContractDeprecatedEntitiesDeployContractResponseChain** | The blockchain where the NFT has been minted. | [optional] 
**transactionHash** | **String** | Deployed contract transaction hash which is a unique string of characters that is given to every transaction that is added to the blockchain. | [optional] 
**transactionExternalUrl** | **String** | Transaction URL in an external blockchain explorer. | [optional] 
**contractName** | **String** | Name of the deployed NFT contract | [optional] 
**contractSymbol** | **String** | Symbol of the deployed NFT contract | [optional] 
**error** | **String** | Error | [optional] 
