# DiGiOfficialsNftApi.Bids

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | Activity type. | 
**bidderAddress** | **String** | Account address of the bidder. | 
**nft** | **AllOfBidsNft** | Details of the NFT. | 
**quantity** | **Number** | Number of NFTs bid on (can be more than 1 NFT for ERC1155). | [optional] 
**priceDetails** | **AllOfBidsPriceDetails** | Price details of the bid. | 
**transactionHash** | **String** | A unique 66-character identifier that is generated when a transaction is executed on the blockchain. | [optional] 
**blockHash** | **String** | The hash of the block header in which the transaction is recorded. | [optional] 
**blockNumber** | **Number** | Number of the block in which the transaction is recorded. | [optional] 
**transactionDate** | **String** | Date of the transaction (ISO). | 
**marketplace** | **AllOfBidsMarketplace** | Marketplace where the bid was made. | [optional] 

<a name="TypeEnum"></a>
## Enum: TypeEnum

* `bid` (value: `"bid"`)
* `cancelBid` (value: `"cancel_bid"`)

