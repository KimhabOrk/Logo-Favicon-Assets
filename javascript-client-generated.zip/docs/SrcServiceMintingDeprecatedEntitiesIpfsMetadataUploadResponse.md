# DiGiOfficialsNftApi.SrcServiceMintingDeprecatedEntitiesIpfsMetadataUploadResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**metadataIpfsUri** | **String** |  | [optional] 
**error** | **String** | Error response. | [optional] 
