# DiGiOfficialsNftApi.AllOfCollectionStatsResponseStatistics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
