# DiGiOfficialsNftApi.AnyOfTransactionsByAccountResponseTransactionsItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
