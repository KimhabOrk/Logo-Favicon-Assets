# DiGiOfficialsNftApi.Chain7

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
