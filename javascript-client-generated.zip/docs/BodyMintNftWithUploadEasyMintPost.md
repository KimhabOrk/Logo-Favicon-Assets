# DiGiOfficialsNftApi.BodyMintNftWithUploadEasyMintPost

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file** | **Blob** |  | 
