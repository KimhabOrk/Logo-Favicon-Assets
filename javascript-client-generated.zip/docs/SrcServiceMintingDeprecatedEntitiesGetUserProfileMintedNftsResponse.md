# DiGiOfficialsNftApi.SrcServiceMintingDeprecatedEntitiesGetUserProfileMintedNftsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Response status, either OK or NOK. | 
**total** | **Number** | Total number of NFTs minted. | [optional] 
**mintedNfts** | [**[SrcServiceMintingDeprecatedEntitiesUserMintedNftResponse]**](SrcServiceMintingDeprecatedEntitiesUserMintedNftResponse.md) | User minted NFTs | [optional] 
**error** | **String** | Error response. | [optional] 
