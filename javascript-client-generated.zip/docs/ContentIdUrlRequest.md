# DiGiOfficialsNftApi.ContentIdUrlRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | URL that points to the image that returns a Content-Length and Content-Type header or contains the file extension. Supports .JPG, .JPEG, .PNG, .WebP, .PPM, .BMP, .PGM, .TIF, .TIFF file formats. | 
**pageNumber** | **Number** | The page number of the results to return. The first page is 1. | [optional] [default to 1]
**pageSize** | **Number** | The number of results returned per page. Limit can range between 1 and 50, and the default is 50. | [optional] [default to 50]
**threshold** | **Number** | Threshold for classifying an NFT as a counterfeit. | [optional] [default to 0.9]
**filterOutContractAddress** | **String** | NFTs from this contract address will be filtered out. Useful for examples where the whole NFT collection is visually very similar e.g. CryptoPunks. | [optional] 
