'use strict';


/**
 * List all your deployed contracts
 * Returns a list of all the contracts you’ve previously deployed with [Deploy an NFT contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzU-deploy-an-nft-contract).  #### Useful for: * Retrieving your contract creation history.  #### Related: * To see all the NFTs you've previously minted, see [List all your minted NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODI-list-all-your-minted-nf-ts).
 *
 * returns GetUserProfileContractsResponse
 **/
exports.get_user_contracts_v0_me_contracts_get = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "contracts" : [ {
    "name" : "Good Company Tokens",
    "symbol" : "GCT",
    "transaction_hash" : "0x124141or0f10140112381381dd",
    "chain" : "rinkeby",
    "address" : "0x12f28e2106ce8fd8464885b80ea865e98b465149",
    "owner_address" : "0x5FDd0881Ef284D6fBB2Ed97b01cb13d707f91e42",
    "creation_date" : "2021-08-23T17:25:03.501703",
    "metadata_frozen" : true,
    "type" : "erc721"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List all your minted NFTs
 * Returns a list of all the NFTs you’ve previously minted with [Easy minting w/URL](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDM-easy-minting-w-url), [Easy minting w/file upload](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDQ-easy-minting-w-file-upload) or [Customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting).  #### Useful for: * Retrieving your NFT minting history.  #### Related: * To see all the contracts you've previously deployed, see [List all your deployed contracts](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODE-list-all-your-deployed-contracts).
 *
 * chain String Blockchain where the NFTs have been minted. (optional)
 * page_number Integer The page number of the results to return. The first page is 1. (optional)
 * page_size Integer The number of results returned per page. Limit can range between 1 and 50, and the default is 50. (optional)
 * returns src__service__minting__entities__GetUserProfileMintedNftsResponse
 **/
exports.get_user_minted_nfts_v0_me_mints_get = function(chain,page_number,page_size) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "total" : 1,
  "minted_nfts" : [ {
    "chain" : "polygon",
    "transaction_hash" : "0x124141or0f10140112381381dd",
    "contract_name" : "My DiGiOfficial's NFT contract",
    "contract_address" : "0xb47e3cd837ddf8e4c57f05d70ab865de6e193bbb",
    "type" : "erc721",
    "token_id" : "6473",
    "mint_to_address" : "0xc155f9bd6b71e9f71d0236b689ad7c2c5d16febf",
    "metadata_uri" : "ipfs://QmTz7dGHvXghNuh3V64QBwHPXva4chpMR7frpfxCaxvhd4",
    "quantity" : "1",
    "metadata_frozen" : true,
    "mint_date" : "2021-08-23T17:25:03.501703"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * User settings
 * Retrieve your DiGiOfficial's NFT settings to check your usage and limits. #### Useful for: * Checking your minting and contract deployment usage and limits. * Checking your NFT Data rate limits  #### Related: * To see your minted NFTs, see [List all your minted NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODI-list-all-your-minted-nf-ts). * To see your deployed contracts, see [List all your deployed contracts](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODE-list-all-your-deployed-contracts).
 *
 * returns GetUserProfileSettingsResponse
 **/
exports.get_user_settings_v0_me_settings_get = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "profile" : {
    "name" : "Satoshi Nakamoto",
    "email" : "satoshi@bitcoin.org",
    "joined_date" : "2021-10-17T00:00:00+00:00"
  },
  "subscription_period" : {
    "start_date" : "2022-01-18T12:40:51.519608",
    "end_date" : "2022-02-17T12:40:51.519613"
  },
  "nft_data_limits" : {
    "nft_data_requests_limit_daily" : 5000,
    "nft_data_requests_limit_second" : 4
  },
  "minting_usage_and_limits" : {
    "polygon" : {
      "minting_usage" : {
        "total_nfts_minted" : 12856,
        "subscription_nfts_minted" : 2856
      },
      "minting_limits" : {
        "subscription_mints_included" : 500
      },
      "contract_deployment_usage" : {
        "total_contracts_deployed" : 18,
        "subscription_contracts_deployed" : 4
      },
      "contract_deployment_limits" : {
        "subscription_contracts_included" : 15
      }
    },
    "rinkeby" : {
      "minting_usage" : {
        "total_nfts_minted" : 9895,
        "subscription_nfts_minted" : 1100
      },
      "minting_limits" : {
        "subscription_mints_included" : 500
      },
      "contract_deployment_usage" : {
        "total_contracts_deployed" : 8,
        "subscription_contracts_deployed" : 6
      },
      "contract_deployment_limits" : {
        "subscription_contracts_included" : 15
      }
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

