'use strict';


/**
 * Deploy an NFT contract
 * Before you can start minting NFTs with /[mint_nft](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTM4MTY5OTc-mint-an-nft) or [/mint_nft_with_upload](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTM5MDY3Mjc-mint-an-nft-with-file-uploads),  a contract representing your collections has to be created.  The endpoint deploys a standard [ERC-721](https://eips.ethereum.org/EIPS/eip-721) smart contract where your NFTs will be minted.  You need to specify the chain (either [Polygon](https://decrypt.co/resources/what-is-polygon-matic-and-why-it-matters-for-ethereum) or [Rinkeby](https://ethereum.org/en/developers/docs/networks)), the name and symbol of your contract.  Returns transaction hash of the created contract that can be used to get your contract address under the endpoint [GET /contract](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTc0MDA0NDc-returns-deployed-contract-info).  Keep in mind that blockchains can be slow at times and minting does not happen immediately. Therefore, after contract deployment, the end-point [GET /contract](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTc0MDA0NDc-returns-deployed-contract-info) should be polled until the deployed contract address is returned.     
 *
 * body DeployContractRequest 
 * returns src__service__contract__deprecated__entities__DeployContractResponse
 **/
exports.deploy_contract_contract_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "transaction_hash" : "0x773ea27408d521898aaf20067e6b8e252b6aa5f0067878da6e2f22fe6fe3eee8",
  "transaction_external_url" : "https://polygonscan.com/tx/0xb1ffb9907e4b72cd89b81e00c4c233d1cc7c661f96f65979048eb6332deb467e",
  "contract_name" : "DiGiOfficial's NFT.xyz",
  "contract_symbol" : "NFTP"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Return deployed contract info
 * After getting the transaction hash by deploying your contract with [POST /contract](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTc0MDA0NDg-deploy-an-nft-contract), this end-point can be used to check if the contract is on chain and get the contract address for /[mint_nft](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTM4MTY5OTc-mint-an-nft) or [/mint_nft_with_upload](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTM5MDY3Mjc-mint-an-nft-with-file-uploads)  As blockchains take time to sync, this endpoint should be polled until the contract address is returned.     
 *
 * chain chain_5 Blockchain where the NFTs smart contract lives
 * transaction_hash String Transaction hash that was returned from deploy contract endpoint
 * returns GetDeployedContractResponse
 **/
exports.get_deployed_contract_contract_get = function(chain,transaction_hash) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "rinkeby",
  "contract_address" : "0x38a554984cf2205f7903123adeb6d560f46625e8",
  "transaction_hash" : "0x19ff77a6faebb740168689dfbf0feb63dc4c4b3797235fc8111716f2383e1715"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

