'use strict';


/**
 * Search over NFT visual content by image file
 * Visual content search of NFTs by image file.  Uses ML models to match the input image file with the visual content of the indexed NFTs.  Returns available details (contract address, token ID, image URL etc.) of NFTs that are similar to the input image.  Ethereum mainnet and Polygon are supported.  To get data from other chains, [contact us.](https://www.digiofficial.xyz/contact)  **Maximum supported filesize is 20MB.**
 *
 * returns src__service__search__deprecated__entities__SearchResult
 **/
exports.search_file_visual_search_by_file_post = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "reason" : "reason",
  "images" : [ {
    "chain" : "",
    "external_url" : "external_url",
    "token_id" : "token_id",
    "image_url" : "image_url",
    "contract_address" : "contract_address",
    "raw_metadata" : { }
  }, {
    "chain" : "",
    "external_url" : "external_url",
    "token_id" : "token_id",
    "image_url" : "image_url",
    "contract_address" : "contract_address",
    "raw_metadata" : { }
  } ],
  "response" : "response"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Search over NFT visual content by image url
 * Visual content search of NFTs by image url (.jpg, .jpeg, .png, .webp allowed).  Uses ML models to match the image in the linked URL with the visual content of the indexed NFTs.  Returns available details (contract address, token ID, image URL etc.) of NFTs that are similar to the linked URL.  Ethereum mainnet and Polygon are supported.  To get data from other chains, [contact us.](https://www.digiofficial.xyz/contact)  **Maximum supported filesize is 20MB.**
 *
 * body Src__service__search__deprecated__search_url_request__SearchUrlRequest 
 * returns src__service__search__deprecated__entities__SearchResult
 **/
exports.search_url_visual_search_by_url_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "reason" : "reason",
  "images" : [ {
    "chain" : "",
    "external_url" : "external_url",
    "token_id" : "token_id",
    "image_url" : "image_url",
    "contract_address" : "contract_address",
    "raw_metadata" : { }
  }, {
    "chain" : "",
    "external_url" : "external_url",
    "token_id" : "token_id",
    "image_url" : "image_url",
    "contract_address" : "contract_address",
    "raw_metadata" : { }
  } ],
  "response" : "response"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Search over NFT visual content by keywords
 * Visual content search from NFTs by keywords.  Uses ML models to match the keywords with the visual content of the indexed NFTs.  Returns available details (contract address, token ID, image URL etc.) of NFTs that have sufficient  relation with the keywords.  Ethereum mainnet and Polygon are supported.  To get data from other chains, [contact us.](https://www.digiofficial.xyz/contact)
 *
 * body SearchRequest 
 * returns src__service__search__deprecated__entities__SearchResult
 **/
exports.search_visual_search_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "reason" : "reason",
  "images" : [ {
    "chain" : "",
    "external_url" : "external_url",
    "token_id" : "token_id",
    "image_url" : "image_url",
    "contract_address" : "contract_address",
    "raw_metadata" : { }
  }, {
    "chain" : "",
    "external_url" : "external_url",
    "token_id" : "token_id",
    "image_url" : "image_url",
    "contract_address" : "contract_address",
    "raw_metadata" : { }
  } ],
  "response" : "response"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

