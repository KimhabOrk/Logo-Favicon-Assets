'use strict';


/**
 * Upload a file to IPFS
 * Uploads a file to [IPFS](https://docs.ipfs.io/concepts/what-is-ipfs/) which makes your NFT storage easy. You can use the returned  ```ipfs_url```  with [Upload metadata to IPFS](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzc-upload-metadata-to-ipfs) to mint your NFT.  If you prefer hosting files in your own servers, you can skip this step. Otherwise, we recommend using IPFS because it's an industry standard for decentralized storage and guarantees the immutability of your files. We use [nft.storage](https://nft.storage/) to [pin](https://docs.ipfs.io/how-to/pin-files/) the files with Filecoin, which ensures that your important data is retained in IPFS.  **Supports all file types and maximum file size is 20MB. For higher limits, see [pricing](https://www.digiofficial.xyz/pricing).**  #### Useful for: * Storing your NFT files easily and according to the industry standards.  #### Related: * After uploading files, use [Upload metadata to IPFS](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzc-upload-metadata-to-ipfs) to continue with your NFT minting. * If you want to learn how to use the [customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting), see [Customizable Minting Quickstart](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#customizable-minting).  #### Example Requests in cURL, Python & JS  <!-- title: \"Make sure to replace the parameters with your own values\" lineNumbers: true -->  ```shell curl --request POST \\     --url 'https://api.digiofficial.xyz/v0/files' \\     --header 'Authorization: API Key Here' \\     --header 'Content-Type: multipart/form-data' \\     --form 'file=@/path/to/file_to_upload.png;type=image/png' ```  ```python import requests  file = open(\"image.png\", \"rb\")  response = requests.post(     \"https://api.digiofficial.xyz/v0/files\",     headers={\"Authorization\": 'API-Key-Here'},     files={\"file\": file} ) ```  ```javascript const fs = require('fs'); const fetch = require('node-fetch'); const FormData = require('form-data');  const form = new FormData(); const fileStream = fs.createReadStream('image.jpg'); form.append('file', fileStream);  const options = {   method: 'POST',   body: form,   headers: {     \"Authorization\": \"API-Key-Here\",   }, };  fetch(\"https://api.digiofficial.xyz/v0/files\", options)   .then(response => {     return response.json()   })   .then(responseJson => {     // Handle the response     console.log(responseJson);   }) ```
 *
 * returns IpfsFileUploadResponse
 **/
exports.ipfs_upload_file_v0_files_post = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "ipfs_url" : "https://ipfs.io/ipfs/QmRModSr9gQTSZrbfbLis6mw21HycZyqMA3j8YMRD11nAQ",
  "file_name" : "name.jpeg",
  "content_type" : "image/jpeg",
  "file_size" : 85138,
  "file_size_mb" : 0.0812
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Upload metadata to IPFS
 * Uploads NFT metadata to [IPFS](https://docs.ipfs.io/concepts/what-is-ipfs/) as a JSON file which is the standard format for  [NFT metadata](https://nftschool.dev/reference/metadata-schemas/#intro-to-json-schemas). You can use the returned ```metadata_ipfs_uri``` in [Customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting) to mint your NFT.  If you prefer hosting metadata in your own servers, you can skip this step. Otherwise, we recommend using IPFS because it’s an industry standard for decentralized storage and guarantees the immutability of your metadata. For the ```file_url```, we also recommend using IPFS with [Upload a file to IPFS](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzY-upload-a-file-to-ipfs). We use [nft.storage](https://nft.storage/) to [pin](https://docs.ipfs.io/how-to/pin-files/) the files with Filecoin, which ensures that your important data is retained in IPFS.  #### Useful for: * Storing your NFT metadata easily and according to the industry standards.  #### Related: * After uploading your metadata, use [Customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting) to continue with your NFT minting. * If you want to learn how to use the customizable minting, see [Customizable Minting Quickstart](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#customizable-minting). * If you are new to NFT metadata, see the [basics on it](https://nftschool.dev/reference/metadata-schemas/).
 *
 * body Src__service__minting__entities__IpfsMetadataUploadRequest 
 * returns src__service__minting__entities__IpfsMetadataUploadResponse
 **/
exports.ipfs_upload_metadata_v0_metadata_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "metadata_uri" : "ipfs://QmTz7dGHvXghNuh3V64QBwHPXva4chpMR7frpfxCaxvhd4",
  "name" : "My Art",
  "description" : "This is my custom art piece",
  "file_url" : "https://ipfs.io/ipfs/QmRModSr9gQTSZrbfbLis6mw21HycZyqMA3j8YMRD11nAQ"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

