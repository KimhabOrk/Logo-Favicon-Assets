'use strict';


/**
 * Easy minting w/URL
 * With Easy mint, you can turn anything into an NFT in less than 5 minutes using one simple API call. If you are new to minting, see  [Easy minting quickstart](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#easy-minting).  After minting, the NFT will appear in the  ```mint_to_address```  wallet. If you minted to your own wallet, you can also see the minted NFT on OpenSea in your profile after a few minutes.  **You can mint up to 100 NFTs for free per chain. Maximum supported file size is 20MB. For higher limits, see [pricing](https://www.digiofficial.xyz/pricing).**  #### Useful for: * For turning anything into an NFT effortlessly. For all the benefits, see  [Your New Minting Superpowers](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#what-you-can-do-with-your-new-minting-superpowers).  #### Related: * If you wish to customize the minting process e.g. use your own contract, see  [Customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#advanced-minting-apis). * If you wish to list all your previously minted NFTs, see [List all your minted NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODI-list-all-your-minted-nf-ts).
 *
 * body EasyMintNftRequest 
 * returns MintNftWithUploadResponse
 **/
exports.easy_mint_nft_v0_mints_easy_urls_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "contract_address" : "0x47c7ff137d7a6644a9a96f1d44f5a6f857d9023f",
  "transaction_hash" : "0x6eb71286f4875bf48be7834c1ff285910583705714f5a5acff67489f94e14954",
  "transaction_external_url" : "https://polygonscan.com/tx/0x6eb71286f4875bf48be7834c1ff285910583705714f5a5acff67489f94e14954",
  "mint_to_address" : "0x5FDd0881Ef284D6fBB2Ed97b01cb13d707f91e42",
  "name" : "DiGiOfficial's NFT.xyz",
  "description" : "One-Stop & Simple NFT Infrastructure & APIs for Developers"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Easy minting w/file upload
 * With Easy mint, you can turn anything into an NFT in less than 5 minutes using one simple API call. If you are new to minting, see  [Easy minting quickstart](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#easy-minting).  After minting, the NFT will appear in the  ```mint_to_address```  wallet. If you minted to your own wallet, you can also see the minted NFT on OpenSea in your profile after a few minutes.  **You can mint up to 100 NFTs for free per chain. Maximum supported file size is 20MB. For higher limits, see [pricing](https://www.digiofficial.xyz/pricing).**  #### Useful for: * For turning anything into an NFT effortlessly. For all the benefits, see  [Your New Minting Superpowers](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#what-you-can-do-with-your-new-minting-superpowers).  #### Related: * If you wish to customize the minting process e.g. use your own contract, see  [Customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#advanced-minting-apis). * If you wish to list all your previously minted NFTs, see [List all your minted NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODI-list-all-your-minted-nf-ts).  #### Example Requests in cURL, Python & JS  <!-- title: \"Make sure to replace the parameters with your own values\" lineNumbers: true -->  ```shell curl --request POST \\     --url 'https://api.digiofficial.xyz/v0/mints/easy/files?chain=polygon&name=NFT_Name&description=NFT_Description&mint_to_address=0x...' \\     --header 'Authorization: API Key Here' \\     --header 'Content-Type: multipart/form-data' \\     --form 'file=@/path/to/file_to_upload.png;type=image/png' ```  ```python import requests  file = open(\"image.png\", \"rb\")  query_params = {     \"chain\": \"polygon\",     \"name\": \"NFT_Name\",     \"description\": \"NFT_Description\",     \"mint_to_address\": Wallet_Address }  response = requests.post(     \"https://api.digiofficial.xyz/v0/mints/easy/files\",     headers={\"Authorization\": \"API-Key-Here\"},     params=query_params,     files={\"file\": file} ) ```  ```javascript const fs = require('fs'); const fetch = require('node-fetch'); const FormData = require('form-data');  const form = new FormData(); const fileStream = fs.createReadStream('/path/to/file_to_upload.png'); form.append('file', fileStream);  const options = {   method: 'POST',   body: form,   headers: {     \"Authorization\": \"API-Key-Here\",   }, };  fetch(\"https://api.digiofficial.xyz/v0/mints/easy/files?\" + new URLSearchParams({   chain: 'polygon',   name: \"NFT_Name\",   description: \"NFT_Description\",   mint_to_address: \"Wallet_Address\", }), options)   .then(function(response) { return response.json() })   .then(function(responseJson) {     // Handle the response     console.log(responseJson);   }) ```
 *
 * chain String Blockchain to mint the NFT on.
 * name String Name of the NFT.
 * description String Text description of the NFT which will be seen on NFT marketplaces, etc.
 * mint_to_address String Account address where the NFT will be sent. For example, your Metamask wallet address if you wish to send it to yourself.
 * returns MintNftWithUploadResponse
 **/
exports.easy_mint_nft_with_upload_v0_mints_easy_files_post = function(chain,name,description,mint_to_address) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "contract_address" : "0x47c7ff137d7a6644a9a96f1d44f5a6f857d9023f",
  "transaction_hash" : "0x6eb71286f4875bf48be7834c1ff285910583705714f5a5acff67489f94e14954",
  "transaction_external_url" : "https://polygonscan.com/tx/0x6eb71286f4875bf48be7834c1ff285910583705714f5a5acff67489f94e14954",
  "mint_to_address" : "0x5FDd0881Ef284D6fBB2Ed97b01cb13d707f91e42",
  "name" : "DiGiOfficial's NFT.xyz",
  "description" : "One-Stop & Simple NFT Infrastructure & APIs for Developers"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve batch minted NFTs
 * Returns the details of a batch minted NFTs for ERC1155 contracts. You need to provide  ```transaction_hash```  which is returned from [Batch customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MzIxMzAwOTk-batch-customizable-minting-erc-1155). Minting is not instantaneous because blockchains take time to verify transactions. Thus, you can poll this endpoint every 5 seconds until you get a response.  #### Useful for: * Confirming that NFT minting was successful and the NFTs are on chain.  #### Related: * For batch customizable minting, see [Batch customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MzIxMzAwOTk-batch-customizable-minting-erc-1155). * If you wish to list all your previously minted NFTs, see [List all your minted NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODI-list-all-your-minted-nf-ts).
 *
 * transaction_hash String 
 * chain String Blockchain the NFT was minted on.
 * returns GetBatchMintedNftResponse
 **/
exports.get_batch_minted_nft_v0_mints_batch__transaction_hash__get = function(transaction_hash,chain) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "contract_address" : "0x47c7ff137d7a6644a9a96f1d44f5a6f857d9023f",
  "token_ids" : [ "2" ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve a minted NFT
 * Returns the details of a minted NFT. You need to provide  ```transaction_hash```  which is returned from [Easy minting w/URL](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDM-easy-minting-w-url), [Easy minting w/file upload](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDQ-easy-minting-w-file-upload) or [Customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting). Minting is not instantaneous because blockchains take time to verify transactions. Thus, you can poll this endpoint every 5 seconds until you get a response.  #### Useful for: * Confirming that NFT minting was successful and the NFT is on chain.  #### Related: * For easy minting, see [Easy minting w/URL](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDM-easy-minting-w-url) or [Easy minting w/file upload](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDQ-easy-minting-w-file-upload). * For customizable minting, see [Customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting). * If you wish to list all your previously minted NFTs, see [List all your minted NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODI-list-all-your-minted-nf-ts).
 *
 * transaction_hash String 
 * chain String Blockchain the NFT was minted on.
 * returns GetMintedNftResponse
 **/
exports.get_minted_nft_v0_mints__transaction_hash__get = function(transaction_hash,chain) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "contract_address" : "0x47c7ff137d7a6644a9a96f1d44f5a6f857d9023f",
  "token_id" : "2"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Batch customizable minting (ERC1155)
 * Batch mints NFTs to your previously deployed ERC1155 contract (i.e. collection). This minting consists of multiple steps and enables you to customize the whole minting flow for your exact needs. Batch minting allows you to create multiple NFTs with one API call and create more than one of the same token.  1.  First, you need  ```contract_address```  using [Deploy an NFT contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzU-deploy-an-nft-contract). 2.  Secondly, you need  ```metadata_uri```  using [Upload metadata to IPFS](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzc-upload-metadata-to-ipfs).  After minting, the NFTs will appear in the  ```mint_to_address```  wallet. If you minted to your own wallet, you can also see the minted NFTs on OpenSea in your profile after a few minutes.  **You can mint up to 100 NFTs for free per chain. Maximum supported filesize is 20MB. For higher limits, see [pricing](https://www.digiofficial.xyz/pricing).**  #### Useful for: * Minting to your own contracts (i.e. collections) effortlessly. * Creating customizable minting flows which enable to build NFT-based products.  #### Related: * If you want to learn how to use [customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting), see [Customizable Minting Quickstart](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#customizable-minting). * If you wish to list all your previously minted NFTs, see [List all your minted NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODI-list-all-your-minted-nf-ts).
 *
 * body MintBatchNftRequest 
 * returns MintBatchResponse
 **/
exports.mint_batch_nft_v0_mints_customizable_batch_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "contract_address" : "0xC8D297D7b496f86673551c933815B47973FC4a0e",
  "transaction_hash" : "0xcbbe6072d7aa48b9774ed8b15e7f298489c5e965b32aa468ca520b30aba649a1",
  "transaction_external_url" : "https://polygonscan.com/tx/0xcbbe6072d7aa48b9774ed8b15e7f298489c5e965b32aa468ca520b30aba649a1",
  "tokens" : [ {
    "mint_to_address" : "0x5FDd0881Ef284D6fBB2Ed97b01cb13d707f91e42",
    "token_id" : "123",
    "metadata_uri" : "ipfs://QmTz7dGHvXghNuh3V64QBwHPXva4chpMR7frpfxCaxvhd4",
    "quantity" : "1"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Customizable minting
 * Mints an NFT to your previously deployed contract (i.e. collection). This minting consists of multiple steps and enables you to customize the whole minting flow for your exact needs.  1.  First, you need  ```contract_address```  using [Deploy an NFT contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzU-deploy-an-nft-contract). 2.  Secondly, you need  ```metadata_uri```  using [Upload metadata to IPFS](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzc-upload-metadata-to-ipfs).  After minting, the NFT will appear in the  ```mint_to_address```  wallet. If you minted to your own wallet, you can also see the minted NFT on OpenSea in your profile after a few minutes.  **You can mint up to 100 NFTs for free per chain. Maximum supported filesize is 20MB. For higher limits, see [pricing](https://www.digiofficial.xyz/pricing).**  #### Useful for: * Minting to your own contracts (i.e. collections) effortlessly. * Creating customizable minting flows which enable to build NFT-based products.  #### Related: * If you want to learn how to use [customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting), see [Customizable Minting Quickstart](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#customizable-minting). * If you wish to list all your previously minted NFTs, see [List all your minted NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODI-list-all-your-minted-nf-ts).
 *
 * body MintNftRequest 
 * returns MintNftResponse
 **/
exports.mint_nft_v0_mints_customizable_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "contract_address" : "0xC8D297D7b496f86673551c933815B47973FC4a0e",
  "transaction_hash" : "0xcbbe6072d7aa48b9774ed8b15e7f298489c5e965b32aa468ca520b30aba649a1",
  "transaction_external_url" : "https://polygonscan.com/tx/0xcbbe6072d7aa48b9774ed8b15e7f298489c5e965b32aa468ca520b30aba649a1",
  "metadata_uri" : "ipfs://QmTz7dGHvXghNuh3V64QBwHPXva4chpMR7frpfxCaxvhd4",
  "mint_to_address" : "0x5FDd0881Ef284D6fBB2Ed97b01cb13d707f91e42"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update a minted NFT
 * Updates an NFT which has been previously minted with [Customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting) or [Batch customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MzIxMzAwOTk-batch-customizable-minting-erc-1155). You can update the metadata URI with a new link or freeze the metadata URI to permanently lock it. The NFT must be minted in your deployed contract and update only works if contract and token are not frozen.  1.  First, you need ```contract_address``` from [Deploy an NFT contract](https://digiofficial.stoplight.io/docs/digiofficial/b3A6MjE0MDYzNzU-deploy-an-nft-contract) and ```metadata_updatable``` must be set ```true```. 2.  Secondly, you need ```token_id``` from [Customizable minting](https://digiofficial.stoplight.io/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting) or [Batch customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MzIxMzAwOTk-batch-customizable-minting-erc-1155). 3.  If you only wish to update the metadata URI set a new ```metadata_uri```. If you wish to update metadata URI and freeze both at the same time then set a new ```metadata_uri``` and ```freeze_metadata``` as ```true```. If you only want to freeze existing metadata URI, then set ```freeze_metadata``` as ```true```.  #### Useful for: * Creating dynamic NFTs (NFTs that change after minting based on events). * Revealing NFTs after the drop.  #### Related: * If you want to learn how to use [customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting), see [Customizable Minting Quickstart](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#customizable-minting). * If you wish to list all your previously minted NFTs, see [List all your minted NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODI-list-all-your-minted-nf-ts).
 *
 * body UpdateNftRequest 
 * returns UpdateNftResponse
 **/
exports.update_nft_v0_mints_customizable_put = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "contract_address" : "0xC8D297D7b496f86673551c933815B47973FC4a0e",
  "transaction_hash" : "0xcbbe6072d7aa48b9774ed8b15e7f298489c5e965b32aa468ca520b30aba649a1",
  "transaction_external_url" : "https://polygonscan.com/tx/0xcbbe6072d7aa48b9774ed8b15e7f298489c5e965b32aa468ca520b30aba649a1",
  "token_id" : "1",
  "token_uri" : "ipfs://QmTz7dGHvXghNuh3V64QBwHPXva4chpMR7frpfxCaxvhd4",
  "freeze_metadata" : false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

