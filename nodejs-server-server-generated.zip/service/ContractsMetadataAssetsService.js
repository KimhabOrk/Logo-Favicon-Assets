'use strict';


/**
 * Retrieve NFT details
 * Returns details for a given NFT. These include ```metadata_url```, ```metadata``` such as name, description, attributes, etc., ```image_url```, ```cached_image_url``` and ```mint_date```. Ethereum and Polygon are supported.  #### Useful for: * For easily getting all the necessary information about a given NFT.  #### Related: * To get all NFTs per contract, see [Retrieve contract NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTQ-retrieve-contract-nf-ts). * To get NFTs that a given account owns, see [Retrieve NFTs owned by an account](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzM-retrieve-nf-ts-owned-by-an-account).
 *
 * contract_address String 
 * token_id String 
 * chain String Blockchain where the NFT has been minted.
 * refresh_metadata Boolean Queues and refreshes the metadata of the token if it has changed since the ```updated_date```. Useful for example, when NFT collections are revealed. (optional)
 * returns src__service__nfts__entities__NftDetailsResponse
 **/
exports.nft_details_v0_nfts__contract_address___token_id__get = function(contract_address,token_id,chain,refresh_metadata) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "nft" : {
    "chain" : "ethereum",
    "contract_address" : "0x12f28e2106ce8fd8464885b80ea865e98b465149",
    "token_id" : "100030071",
    "metadata_url" : "https://api.niftygateway.com/beeple/100030071/",
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    },
    "file_information" : {
      "height" : 512,
      "width" : 512,
      "file_size" : 310751
    },
    "file_url" : "https://lh3.googleusercontent.com/79JB1V9gSMv83iMs-Db4qdpPVdpKiyt_sjGLgs575wLEgWjSRLCzMQMoxaealYz7AVCKY_mzSy6GlOYdGt_7aaCZfg",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0x12f28e2106ce8fd8464885b80ea865e98b465149_t_100030071_raw_asset.png",
    "mint_date" : "2020-10-29T15:03:54.838612",
    "updated_date" : "2021-10-19T15:03:54.838612"
  },
  "contract" : {
    "name" : "Decentraland LAND",
    "symbol" : "LAND",
    "type" : "ERC721"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve contract NFTs
 * Returns all NFTs for a given contract address. Can be set to ```include``` the NFT ```metadata``` or ```all``` which returns extra information. Ethereum and Polygon are supported.  #### Useful for: * Importing all NFTs from a given contract to your application.  #### Related: * To get detailed information on the returned NFTs, see [Retrieve NFT details](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTM-retrieve-nft-details). * To get NFTs that a given account owns, see [Retrieve NFTs owned by an account](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzM-retrieve-nf-ts-owned-by-an-account).
 *
 * contract_address String 
 * chain String Blockchain from which to query NFTs.
 * page_number Integer The page number of the results to return. The first page is 1. (optional)
 * page_size Integer The number of results returned per page. Limit can range between 1 and 50, and the default is 50. (optional)
 * include include Include optional data in the response. default is the default response, metadata includes NFT metadata and cached_file_url, and all includes extra information like file_information and mint_date in [Retrieve NFT details](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTM-retrieve-nft-details). (optional)
 * refresh_metadata Boolean Queues and refreshes all the NFTs metadata inside the contract (i.e. all tokens) if they have changed since the ```updated_date```. Useful for example, when NFT collections are revealed. (optional)
 * returns ContractNftsResponse
 **/
exports.nfts_by_contract_v0_nfts__contract_address__get = function(contract_address,chain,page_number,page_size,include,refresh_metadata) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "nfts" : [ {
    "chain" : "ethereum",
    "contract_address" : "0x12f28e2106ce8fd8464885b80ea865e98b465149",
    "token_id" : "100030071",
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    },
    "metadata_url" : "https://api.niftygateway.com/beeple/100030071",
    "file_url" : "https://lh3.googleusercontent.com/79JB1V9gSMv83iMs-Db4qdpPVdpKiyt_sjGLgs575wLEgWjSRLCzMQMoxaealYz7AVCKY_mzSy6GlOYdGt_7aaCZfg",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0x12f28e2106ce8fd8464885b80ea865e98b465149_t_100030071_raw_asset.png",
    "mint_date" : "2020-10-29T15:03:54.838612",
    "file_information" : {
      "height" : 512,
      "width" : 512,
      "file_size" : 310751
    },
    "updated_date" : "2021-10-19T15:03:54.838612"
  } ],
  "contract" : {
    "name" : "Decentraland LAND",
    "symbol" : "LAND",
    "type" : "ERC721"
  },
  "total" : 102
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve all NFTs
 * Returns all ERC721 and ERC1155 NFTs that have been minted on a given chain. Can be set to ```include``` the NFT ```metadata```, ```file_information```,  ```contract_infomation``` and ```all``` which includes full details like in [Retrieve NFT details](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTM-retrieve-nft-details). Ethereum and Polygon are supported.  #### Useful for: * Big data analysis or analytics with all the NFTs. * Keeping track of all the created NFTs. * Importing all NFTs to your application.  #### Related: * To get all NFTs per contract, see [Retrieve contract NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTQ-retrieve-contract-nf-ts). * To get detailed information on the returned NFTs, see [Retrieve NFT details](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTM-retrieve-nft-details).
 *
 * chain String Blockchain from which to query NFTs.
 * page_size Integer The number of results returned per page. Limit can range between 1 and 50, and the default is 50. (optional)
 * continuation String Continuation. Pass this value from the previous response to fetch the next page. (optional)
 * include List Include optional data in the response. ```metadata``` includes NFT metadata, ```file_information``` includes extra information of the NFT’s file,  ```contract_infomation``` includes information of the NFT’s contract and ```all``` includes full details like in [Retrieve NFT details](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTM-retrieve-nft-details). Fields can be combined to get desired result. (optional)
 * returns NftsResponse
 **/
exports.nfts_v0_nfts_get = function(chain,page_size,continuation,include) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "nfts" : [ {
    "chain" : "ethereum",
    "contract_address" : "0x12f28e2106ce8fd8464885b80ea865e98b465149",
    "token_id" : "100030071",
    "contract" : {
      "name" : "Decentraland LAND",
      "symbol" : "LAND",
      "type" : "ERC721"
    },
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    },
    "metadata_url" : "https://api.niftygateway.com/beeple/100030071",
    "file_url" : "https://lh3.googleusercontent.com/79JB1V9gSMv83iMs-Db4qdpPVdpKiyt_sjGLgs575wLEgWjSRLCzMQMoxaealYz7AVCKY_mzSy6GlOYdGt_7aaCZfg",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0x12f28e2106ce8fd8464885b80ea865e98b465149_t_100030071_raw_asset.png",
    "mint_date" : "2020-10-29T15:03:54.838612",
    "file_information" : {
      "height" : 512,
      "width" : 512,
      "file_size" : 310751
    },
    "updated_date" : "2021-10-19T15:03:54.838612"
  } ],
  "continuation" : "MHg0Zjg5Y2QwY2FlMWU1NGQ5OGRiNmE4MDE1MGE4MjRhNTMzNTAyZWVhXzI0MzU="
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

