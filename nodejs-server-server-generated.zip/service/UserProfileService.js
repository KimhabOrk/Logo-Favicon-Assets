'use strict';


/**
 * Returns user's contracts
 * Returns the contracts deployed by the DiGiOfficial's NFT user.
 *
 * returns GetUserProfileContractsResponse
 **/
exports.get_user_contracts_me_contracts_get = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "contracts" : [ {
    "name" : "Good Company Tokens",
    "symbol" : "GCT",
    "transaction_hash" : "0x124141or0f10140112381381dd",
    "chain" : "rinkeby",
    "address" : "0x12f28e2106ce8fd8464885b80ea865e98b465149",
    "owner_address" : "0x5FDd0881Ef284D6fBB2Ed97b01cb13d707f91e42",
    "creation_date" : "2021-08-23T17:25:03.501703",
    "metadata_frozen" : true,
    "type" : "erc721"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns NFTs minted by DiGiOfficial's NFT user
 * Returns the details of the NFTs minted by the DiGiOfficial's NFT user.
 *
 * chain chain_7 Blockchain specifying the NFTs smart contract location (optional)
 * page_number Integer Page number (optional)
 * page_size Integer Page size (optional)
 * returns src__service__minting__deprecated__entities__GetUserProfileMintedNftsResponse
 **/
exports.get_user_minted_nfts_me_minted_nfts_get = function(chain,page_number,page_size) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "total" : 0,
  "minted_nfts" : [ {
    "chain" : "polygon",
    "transaction_hash" : "0x124141or0f10140112381381dd",
    "contract_name" : "My DiGiOfficial's NFT contract",
    "contract_address" : "0xb47e3cd837ddf8e4c57f05d70ab865de6e193bbb",
    "token_id" : "6473",
    "minted_address" : "0xc155f9bd6b71e9f71d0236b689ad7c2c5d16febf",
    "metadata_ipfs_uri" : "ipfs://QmTz7dGHvXghNuh3V64QBwHPXva4chpMR7frpfxCaxvhd4",
    "minted_date" : "2021-08-23T17:25:03.501703"
  }, {
    "chain" : "polygon",
    "transaction_hash" : "0x124141or0f10140112381381dd",
    "contract_name" : "My DiGiOfficial's NFT contract",
    "contract_address" : "0xb47e3cd837ddf8e4c57f05d70ab865de6e193bbb",
    "token_id" : "6473",
    "minted_address" : "0xc155f9bd6b71e9f71d0236b689ad7c2c5d16febf",
    "metadata_ipfs_uri" : "ipfs://QmTz7dGHvXghNuh3V64QBwHPXva4chpMR7frpfxCaxvhd4",
    "minted_date" : "2021-08-23T17:25:03.501703"
  } ],
  "response" : "response",
  "error" : "error"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

