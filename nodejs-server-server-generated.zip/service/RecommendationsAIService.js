'use strict';


/**
 * Find similar NFTs w/file upload
 * Returns visually and contextually similar images to the uploaded image with  ```file```. Uses state of the art computer vision AI to match the input image against all ETH & Polygon NFT images in our database. You can think of it like Google reverse image search.  You can see this functionality live with  [Fingible](https://fingible.digiofficial.xyz/).  **Maximum supported file size is 20MB.**  #### Useful for: * Providing recommendations to your users e.g. like Amazon, Netflix so you can increase revenue. * Building new AI-based products and experiences for your users such as  [Google for NFTs](https://fingible.digiofficial.xyz/).  #### Related: * For searching for NFTs with keywords, see [Multi-chain NFT search](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjA0MjY5MjE-multi-chain-nft-search). * For finding duplicates/copies of NFTs, see [Find duplicate NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODY-find-counterfeit-nf-ts-w-file-upload).
 *
 * page_number Integer The page number of the results to return. The first page is 1. (optional)
 * page_size Integer The number of results returned per page. Limit can range between 1 and 50, and the default is 50. (optional)
 * returns src__service__search__entities__SearchResult
 **/
exports.search_file_v0_recommendations_similar_nfts_files_post = function(page_number,page_size) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "nfts" : [ {
    "chain" : "ethereum",
    "contract_address" : "0x12f28e2106ce8fd8464885b80ea865e98b465149",
    "token_id" : "100030071",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0x12f28e2106ce8fd8464885b80ea865e98b465149_t_100030071_raw_asset.png",
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    }
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Find similar NFTs w/URL
 * Returns visually and contextually similar images to the input image passed with ```url```. Uses state of the art computer vision AI to match the input image against all ETH & Polygon NFT images in our database. You can think of it like Google reverse image search.  You can see this functionality live with [Fingible](https://fingible.digiofficial.xyz/).  **Maximum supported file size is 20MB.**  #### Useful for: * Providing recommendations to your users e.g. like Amazon, Netflix so you can increase revenue. * Building new AI-based products and experiences for your users such as [Google for NFTs](https://fingible.digiofficial.xyz/).  #### Related: * For searching for NFTs with keywords, see [Multi-chain NFT search](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjA0MjY5MjE-multi-chain-nft-search). * For finding duplicates/copies of NFTs, see [Find duplicate NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODY-find-counterfeit-nf-ts-w-file-upload).
 *
 * body Src__service__search__search_url_request__SearchUrlRequest 
 * returns src__service__search__entities__SearchResult
 **/
exports.search_url_v0_recommendations_similar_nfts_urls_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "nfts" : [ {
    "chain" : "ethereum",
    "contract_address" : "0x12f28e2106ce8fd8464885b80ea865e98b465149",
    "token_id" : "100030071",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0x12f28e2106ce8fd8464885b80ea865e98b465149_t_100030071_raw_asset.png",
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    }
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

