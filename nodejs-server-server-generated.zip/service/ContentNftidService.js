'use strict';


/**
 * Return visually similar NFTs using copy detection AI
 * Uses state-of-the-art copy detection AI models to analyse NFT images across chains and detect visually similar images i.e. image copies.  ### Some example use-cases:  * **Increase customer trust and lower fraud** - enable users to see if an NFT is unique or already minted/sold somewhere else by showing information on existing duplicate NFTs. * **Credit and protect creators** -  build processes that defend against IP theft and/or credit the original authors when their work has been used in similar NFTs * **Enable and attract large IP holders (e.g. Disney)** to upload content as NFTs by ensuring automatic copyright protection (similar to YouTube's Content ID)  **Supported file formats: jpg, jpeg, png, ppm, bmp, pgm, tif, tiff, webp**  Support for other formats to be added soon.  Images from Ethereum mainnet and Polygon are supported.  To get data from other chains or with other formats, [contact us](https://www.digiofficial.xyz/contact).
 *
 * limit Integer Maximum amount of results (optional)
 * threshold BigDecimal Threshold for classifying an NFT as a match (optional)
 * contract_address String NFTs from this contract address will be filtered out. Useful for examples where the whole NFT collection is visually very similar e.g. CryptoPunks (optional)
 * returns ContentIdResponse
 **/
exports.similar_nfts_similar_nfts_post = function(limit,threshold,contract_address) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "is_similar" : true,
  "similar_nfts" : [ {
    "contract_address" : "0xb47e3cd837ddf8e4c57f05d70ab865de6e193bbb",
    "token_id" : "3100",
    "chain" : "ethereum",
    "similarity" : 0.999998,
    "file_url" : "https://www.larvalabs.com/cryptopunks/cryptopunk3100.png",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0xb47e3cd837ddf8e4c57f05d70ab865de6e193bbb_t_3100_raw_asset.png",
    "metadata_url" : "https://api.niftygateway.com/beeple/100030071/",
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    },
    "mint_date" : "2020-10-29T15:03:54.838612"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

