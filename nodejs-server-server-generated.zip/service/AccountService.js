'use strict';


/**
 * Return NFTs owned by account
 * Returns details (contract address, token URI, name, description, asset URL and creator address) for NFTs owned by given account.  Ethereum and Tezos are supported. To get data from other chains, [contact us.](https://www.digiofficial.xyz/contact)  **For Ethereum use the continuation string from response for pagination, for Polygon and Tezos use page number.**
 *
 * account_address String 
 * chain chain_3 Blockchain where the NFTs smart contract lives
 * page_number Integer Page number (optional)
 * page_size Integer Page size (optional)
 * continuation String Continuation. Pass this value from the previous response to fetch the next page (optional)
 * include include_4 Include optional data (optional)
 * returns src__service__account__deprecated__entities__AccountNftsResponse
 **/
exports.account_nfts_account__account_address__nfts_get = function(account_address,chain,page_number,page_size,continuation,include) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "nfts" : [ {
    "contract_address" : "KT1RJ6PbjHpwc3M5rw5s2Nbmefwbuwbdxton",
    "token_id" : "159383",
    "name" : "Cool name",
    "description" : "Cool description",
    "asset_url" : "ipfs://QmVkyU2c6ade8su1UKqSSx6iNLDp6zrCMUGX8DrRFcm9mq",
    "creator_address" : "tz1dVxdJwpJixh6Kcd5FZULTfFcR98V7Z2fw",
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    }
  } ],
  "total" : 12
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

