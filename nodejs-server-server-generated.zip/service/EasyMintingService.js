'use strict';


/**
 * Return minted NFT
 * Based on the minting transaction hash, returns the minted NFT's contract address and the token ID.  Note that blockchains can be slow and minting can take some time.
 *
 * chain chain_6 Blockchain where the NFTs smart contract lives
 * transaction_hash String Transaction hash that was returned from mint NFT endpoint
 * returns GetMintedNftResponse
 **/
exports.get_minted_nft_get_minted_nft_get = function(chain,transaction_hash) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "contract_address" : "0x47c7ff137d7a6644a9a96f1d44f5a6f857d9023f",
  "token_id" : "2"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Easy mint
 * With Easy mint, you can turn anything into an NFT in less than 120 seconds using one simple API call.  ### Instructions  All the blockchain complexity is taken care for you automatically. You just need to provide:  1. A name for your NFT 2. A description for your NFT 3. The chain where the NFT will be minted. We recommend [Polygon](https://decrypt.co/resources/what-is-polygon-matic-and-why-it-matters-for-ethereum) which enables free and green NFT minting. In short, it's the leading layer 2 scaling solution built on top of Ethereum. Rinkeby is Ethereum's testnet. 4. The [wallet](https://ethereum.org/en/wallets/) address where to mint the NFT. If you want to mint to your own wallet, then provide your own wallet address (e.g. copy-paste from MetaMask). In both Polygon and Rinkeby cases, it's your regular Ethereum wallet address. 5. Select the path to your locally stored file. For example, file=/path/to/file.png. All file types are supported including binary, images, GIFs, videos, audio, documents, text, etc.  <!-- theme: success -->  > #### Your NFT is ready! That was easy, huh? 😎  After minting, the NFT will appear in the specified wallet. You can also see, sell or trade the NFT on OpenSea under your [account](https://opensea.io/account) (if you minted to your own wallet) or at [DiGiOfficial's NFT](https://opensea.io/collection/digiofficial-xyz) collection. It usually takes a few minutes for OpenSea to update their database.  ### Example Requests in cURL, Python & JS  <!-- title: \"Make sure to replace the parameters with your own values\" lineNumbers: true -->  ```shell curl --request POST \\     --url 'https://api.digiofficial.xyz/easy_mint?chain=polygon&name=NFT_Name&description=NFT_Description&mint_to_address=0x...' \\     --header 'Authorization: API Key Here' \\     --header 'Content-Type: multipart/form-data' \\     --form 'file=@/path/to/file_to_upload.png;type=image/png' ```  ```python with open(\"image.png\", \"rb\") as f:     file = f.read()  query_params = {     \"chain\": \"polygon\",     \"name\": \"NFT_Name\",     \"description\": \"NFT_Description\",     \"mint_to_address\": Wallet_Address }  response = requests.post(     \"https://api.digiofficial.xyz/easy_mint\",     headers={\"Authorization\": API_Key},     params=query_params,     files={\"file\": file} ) ```  ```javascript const fs = require('fs'); const fetch = require('node-fetch'); const FormData = require('form-data');  const form = new FormData(); const fileStream = fs.createReadStream('/path/to/file_to_upload.png'); form.append('file', fileStream);  const options = {   method: 'POST',   body: form,   headers: {     \"Authorization\": \"API_Key\",   }, };  fetch(\"https://api.digiofficial.xyz/easy_mint?\" + new URLSearchParams({   chain: 'polygon',   name: \"NFT_Name\",   description: \"NFT_Description\",   mint_to_address: \"Wallet_Address\", }), options)   .then(function(response) { return response.json() })   .then(function(responseJson) {     // Handle the response     console.log(responseJson);   }) ```  <!-- theme: warning -->  > #### Sending a request in the UI widget is not working at the moment for easy mint so we recommend using the Curl or calling it from code.  ### In short, Easy mint automatically:  1. Uploads the file to [IPFS](https://docs.ipfs.io/concepts/what-is-ipfs/) 2. Creates a metadata file (JSON) with the file's name, description and URL and uploads it to IPFS 3. Creates i.e. mints the NFT (with a reference to the metadata URI)  ### Support Please join our [Discord](https://discord.gg/bE2cn9qCRg) community if you need support from our team and a space to discuss NFT related topics, voice feature requests, and engage with other like-minded NFT developers and creators.  ### FAQ  1. **I'm getting an error: There was an error parsing the body.** The interactive code example is unfortunately broken at the moment and the documentation provider is fixing it. Until that, please use the code snippet.  2. **Maximum supported filesize is 20MB.** Write on Discord if you need to mint larger files.  3. **You can mint up to 1000 NFTs for free per chain.** This is to prevent us getting DDOS'd. If you need to mint more than 1K NFTs, then write on Discord.  4. To customize and manage the minting process in separate steps, see [Advanced Minting APIs](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/ZG9jOjE3NDI3MDc3-minting-quickstart#advanced-minting-apis).
 *
 * chain MintNftRequestChain 
 * name String 
 * description String 
 * mint_to_address String 
 * returns MintNftWithUploadResponse
 **/
exports.mint_nft_with_upload_easy_mint_post = function(chain,name,description,mint_to_address) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "contract_address" : "0x47c7ff137d7a6644a9a96f1d44f5a6f857d9023f",
  "transaction_hash" : "0x6eb71286f4875bf48be7834c1ff285910583705714f5a5acff67489f94e14954",
  "transaction_external_url" : "https://polygonscan.com/tx/0x6eb71286f4875bf48be7834c1ff285910583705714f5a5acff67489f94e14954",
  "mint_to_address" : "0x5FDd0881Ef284D6fBB2Ed97b01cb13d707f91e42",
  "name" : "DiGiOfficial's NFT.xyz",
  "description" : "One-Stop & Simple NFT Infrastructure & APIs for Developers"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

