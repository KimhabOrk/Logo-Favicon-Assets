'use strict';


/**
 * Return NFT details
 * Returns details (token URI, available metadata, image URL and mint date) for a given NFT.  Ethereum mainnet and Polygon are supported.  To get data from other chains, [contact us.](https://www.digiofficial.xyz/contact)
 *
 * contract_address String 
 * token_id String 
 * chain chain_2 Blockchain where the NFTs smart contract lives
 * returns src__service__nfts__deprecated__entities__NftDetailsResponse
 **/
exports.nft_details_nfts__contract_address___token_id__get = function(contract_address,token_id,chain) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "nfts" : [ {
    "contract_address" : "0x12f28e2106ce8fd8464885b80ea865e98b465149",
    "token_id" : "100030071",
    "token_uri" : "https://api.niftygateway.com/beeple/100030071/",
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    },
    "asset_metadata" : {
      "height" : 512,
      "width" : 512,
      "file_size" : 310751
    },
    "image_url" : "https://lh3.googleusercontent.com/79JB1V9gSMv83iMs-Db4qdpPVdpKiyt_sjGLgs575wLEgWjSRLCzMQMoxaealYz7AVCKY_mzSy6GlOYdGt_7aaCZfg",
    "cached_image_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0x12f28e2106ce8fd8464885b80ea865e98b465149_t_100030071_raw_asset.png",
    "mint_date" : "2020-10-29T15:03:54.838612"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Return all NFTs for given contract address
 * Returns all NFTs for a given contract address.  Includes NFT metadata in response when include='metadata' is used.  Ethereum mainnet and Polygon are supported.  To get data from other chains, [contact us.](https://www.digiofficial.xyz/contact)
 *
 * contract_address String 
 * chain chain_1 Blockchain where the NFTs smart contract lives
 * page_number Integer Page number (optional)
 * page_size Integer Page size (optional)
 * include include_3 Include optional data (optional)
 * returns ContractNftsResponse
 **/
exports.nfts_by_contract_nfts__contract_address__get = function(contract_address,chain,page_number,page_size,include) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "nfts" : [ {
    "chain" : "ethereum",
    "contract_address" : "0x12f28e2106ce8fd8464885b80ea865e98b465149",
    "token_id" : "100030071",
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    },
    "metadata_url" : "https://api.niftygateway.com/beeple/100030071",
    "file_url" : "https://lh3.googleusercontent.com/79JB1V9gSMv83iMs-Db4qdpPVdpKiyt_sjGLgs575wLEgWjSRLCzMQMoxaealYz7AVCKY_mzSy6GlOYdGt_7aaCZfg",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0x12f28e2106ce8fd8464885b80ea865e98b465149_t_100030071_raw_asset.png",
    "mint_date" : "2020-10-29T15:03:54.838612",
    "file_information" : {
      "height" : 512,
      "width" : 512,
      "file_size" : 310751
    },
    "updated_date" : "2021-10-19T15:03:54.838612"
  } ],
  "contract" : {
    "name" : "Decentraland LAND",
    "symbol" : "LAND",
    "type" : "ERC721"
  },
  "total" : 102
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Return all NFTs
 * Returns all NFTs (contract address and token ID) for a given chain with a maximum of 100 tokens per page.  To get detailed information of the returned NFTs, see [/nfts/{contract_address}/{token_id}](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTc2NjI1MDg-returns-nft-details)  Ethereum mainnet and Polygon are supported.  To get data from other chains, [contact us.](https://www.digiofficial.xyz/contact)
 *
 * chain chain Blockchain where the NFTs smart contract lives
 * page_size Integer Page size (optional)
 * continuation String Continuation. Pass this value from the previous response to fetch the next page. (optional)
 * returns NftsResponse
 **/
exports.nfts_nfts_get = function(chain,page_size,continuation) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "nfts" : [ {
    "chain" : "ethereum",
    "contract_address" : "0x12f28e2106ce8fd8464885b80ea865e98b465149",
    "token_id" : "100030071",
    "contract" : {
      "name" : "Decentraland LAND",
      "symbol" : "LAND",
      "type" : "ERC721"
    },
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    },
    "metadata_url" : "https://api.niftygateway.com/beeple/100030071",
    "file_url" : "https://lh3.googleusercontent.com/79JB1V9gSMv83iMs-Db4qdpPVdpKiyt_sjGLgs575wLEgWjSRLCzMQMoxaealYz7AVCKY_mzSy6GlOYdGt_7aaCZfg",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0x12f28e2106ce8fd8464885b80ea865e98b465149_t_100030071_raw_asset.png",
    "mint_date" : "2020-10-29T15:03:54.838612",
    "file_information" : {
      "height" : 512,
      "width" : 512,
      "file_size" : 310751
    },
    "updated_date" : "2021-10-19T15:03:54.838612"
  } ],
  "continuation" : "MHg0Zjg5Y2QwY2FlMWU1NGQ5OGRiNmE4MDE1MGE4MjRhNTMzNTAyZWVhXzI0MzU="
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

