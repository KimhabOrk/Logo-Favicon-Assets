'use strict';


/**
 * Search over NFT metadata fields name and description
 * Search input text from the name and description metadata fields of NFTs.  Returns details (chain, contract address, token ID, image URL, name, description and minted date) of the NFTs that match the text search input.  Ethereum mainnet and Polygon are supported (including cross-chain search).  To get data from other chains, [contact us.](https://www.digiofficial.xyz/contact)
 *
 * text String Search query
 * chain chain_4 Blockchain where the NFTs smart contract lives
 * page_number Integer Page number (optional)
 * page_size Integer Page size (optional)
 * order_by order_by_1 Results ordering criteria (optional)
 * sort_order sort_order_1 Results will be sorted in this order (ascending/descending) (optional)
 * filter_by_contract_address String Results will only include NFTs from this contract address (optional)
 * returns src__service__text_search__deprecated__entities__TextSearchResponse
 **/
exports.text_search_text_search_get = function(text,chain,page_number,page_size,order_by,sort_order,filter_by_contract_address) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "search_results" : [ {
    "chain" : "ethereum",
    "contract_address" : "0x12f28e2106ce8fd8464885b80ea865e98b465149",
    "token_id" : "100030071",
    "image_url" : "Image url value",
    "name" : "Name field value in NFT metadata",
    "description" : "Description field value in NFT metadata",
    "mint_date" : "2020-10-29T15:03:54.838612"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

