'use strict';


/**
 * Deploy an NFT contract
 * Deploys an [```ERC-721```](https://github.com/digiofficial/solidity-contracts/blob/master/contracts/ERC721NftCustom.sol) or [```ERC-1155```](https://github.com/digiofficial/solidity-contracts/blob/master/contracts/ERC1155NftCustom.sol) smart contract  where your can mint your NFTs. This is a required step if you wish to use [Customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting) as the contract will represent your own collection.  As blockchains take time to sync, then after contract deployment, you can use the returned ```transaction_hash``` in [Retrieve a deployed contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM4OTk-retrieve-a-deployed-contract) to get the ```contract_address```.  **You can deploy up to 5 contracts for free per chain. For higher limits, see [pricing](https://www.digiofficial.xyz/pricing).**  #### Useful for: * Deploying your own contracts so you can build custom products or collections easily.  #### Related: * To get the deployed contract address, use [Retrieve a deployed contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM4OTk-retrieve-a-deployed-contract). * If you want to know how to use the customizable minting, see [Customizable Minting Quickstart](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#customizable-minting).
 *
 * body DeployContractRequestWithAddress 
 * returns src__service__contract__entities__DeployContractResponse
 **/
exports.deploy_contract_v0_contracts_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "transaction_hash" : "0x773ea27408d521898aaf20067e6b8e252b6aa5f0067878da6e2f22fe6fe3eee8",
  "transaction_external_url" : "https://polygonscan.com/tx/0xb1ffb9907e4b72cd89b81e00c4c233d1cc7c661f96f65979048eb6332deb467e",
  "name" : "CRYPTOPUNKS",
  "symbol" : "C",
  "owner_address" : "0x5FDd0881Ef284D6fBB2Ed97b01cb13d707f91e42"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve a deployed contract
 * Returns the details of a contract that has previously been deployed with [Deploy an NFT contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzU-deploy-an-nft-contract). Supply the ```transaction_hash``` to check if the contract is on chain and to get the ```contract_address```. You can use the returned ```contract_address``` in [Customizable Minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting).  As blockchains take time to sync, this endpoint can be polled until the ```contract_address``` is returned.  #### Useful for: * Deploying your own contracts so you can build custom products or collections easily.  #### Related: * If you want to get data about NFT contracts which you haven't deployed using DiGiOfficial's NFT, see [Retrieve contract NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTQ-retrieve-contract-nf-ts). * If you want to learn how to use the [customizable minting](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM5MDI-customizable-minting), see [Customizable Minting Quickstart](https://docs.digiofficial.xyz/docs/digiofficial/ZG9jOjE3NDI3MDc3-minting-quickstart#customizable-minting).
 *
 * transaction_hash String 
 * chain String Blockchain where the contract has been deployed to.
 * returns GetDeployedContractResponse
 **/
exports.get_deployed_contract_v0_contracts__transaction_hash__get = function(transaction_hash,chain) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "rinkeby",
  "contract_address" : "0x38a554984cf2205f7903123adeb6d560f46625e8",
  "transaction_hash" : "0x19ff77a6faebb740168689dfbf0feb63dc4c4b3797235fc8111716f2383e1715"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update a deployed contract
 * Updates a contract which has been previously deployed with [Deploy an NFT contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzU-deploy-an-nft-contract). You can freeze the metadata of the NFTs minted in the specified contract which means they can not be updated after minting (token URIs are frozen on the contract level).  #### Useful for: * Creating dynamic NFTs (NFTs that change after minting based on events) and freezing them afterwards. * Revealing NFTs after a drop and freezing them afterwards.  #### Related: * If you wish to list all your previously deployed contracts, see [List all your deployed contracts](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODE-list-all-your-deployed-contracts).
 *
 * body UpdateContractRequest 
 * returns UpdateContractResponse
 **/
exports.update_contract_v0_contracts_put = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "transaction_hash" : "0x773ea27408d521898aaf20067e6b8e252b6aa5f0067878da6e2f22fe6fe3eee8",
  "transaction_external_url" : "https://polygonscan.com/tx/0xb1ffb9907e4b72cd89b81e00c4c233d1cc7c661f96f65979048eb6332deb467e",
  "freeze_metadata" : true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

