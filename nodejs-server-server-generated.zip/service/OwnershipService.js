'use strict';


/**
 * Retrieve NFTs owned by an account
 * Returns NFTs owned by a given account (i.e. wallet) address. Can also return each NFT metadata with  ```include```  parameter. Ethereum, Tezos and Polygon are supported.  **For Ethereum use the continuation string from response for pagination, for Polygon and Tezos use page number.**  #### Useful for: * For checking if a user owns a specific NFT and then unlocking specific activity. * Adding NFT portfolio section to your apps.  #### Related: * To get all NFTs per contract, see [Retrieve contract NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTQ-retrieve-contract-nf-ts). * To get extra detailed information on the returned NFTs, see [Retrieve NFT details](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTM-retrieve-nft-details).
 *
 * account_address String 
 * chain String Blockchain from which to query NFTs.
 * page_number Integer The page number of the results to return. The first page is 1. (optional)
 * page_size Integer The number of results returned per page. Limit can range between 1 and 50, and the default is 50. (optional)
 * continuation String Continuation. Pass this value from the previous response to fetch the next page. (optional)
 * include include_1 Include optional data in the response. ```default``` is the default response and metadata includes NFT metadata, like in Retrieve NFT details. (optional)
 * returns src__service__account__entities__AccountNftsResponse
 **/
exports.account_nfts_v0_accounts__account_address__get = function(account_address,chain,page_number,page_size,continuation,include) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "nfts" : [ {
    "contract_address" : "KT1RJ6PbjHpwc3M5rw5s2Nbmefwbuwbdxton",
    "token_id" : "159383",
    "name" : "Cool name",
    "description" : "Cool description",
    "file_url" : "ipfs://QmVkyU2c6ade8su1UKqSSx6iNLDp6zrCMUGX8DrRFcm9mq",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0x12f28e2106ce8fd8464885b80ea865e98b465149_t_100030071_raw_asset.png",
    "creator_address" : "tz1dVxdJwpJixh6Kcd5FZULTfFcR98V7Z2fw",
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    },
    "metadata_url" : "https://api.niftygateway.com/beeple/100030071"
  } ],
  "total" : 12
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve NFTs created by an account
 * Returns NFTs created (i.e. minted) by a given account (i.e. wallet) address. Can also return each NFT metadata with `include` parameter. Ethereum mainnet is supported.  #### Useful for: * For displaying NFTs created by an account. * Doing analytics on creator's portfolio.  #### Related: * To get NFTs that a given account owns, see [Retrieve NFTs owned by an account](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzNzM-retrieve-nf-ts-owned-by-an-account). * To get all NFTs per contract, see [Retrieve contract NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTQ-retrieve-contract-nf-ts). * To get extra detailed information on the returned NFTs, see [Retrieve NFT details](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTM-retrieve-nft-details).
 *
 * account_address String 
 * chain String Blockchain from which to query NFTs.
 * page_size Integer The number of results returned per page. Limit can range between 1 and 50, and the default is 50. (optional)
 * continuation String Continuation. Pass this value from the previous response to fetch the next page. (optional)
 * include include_2 Include optional data in the response. ```default``` is the default response and metadata includes NFT metadata, like in Retrieve NFT details. (optional)
 * returns CreatorNftsResponse
 **/
exports.creator_nfts_v0_accounts_creators__account_address__get = function(account_address,chain,page_size,continuation,include) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "nfts" : [ {
    "chain" : "ethereum",
    "contract_address" : "0xafb44cef938b1be600a4331bf9904f6cec2fcac3",
    "token_id" : "4083388403051261561560495289181218537481",
    "name" : "UniSwamp",
    "description" : "The UniSwamp is ground zero for warfare with The Institution and its army of Shills. Technically, “District 16”, Uniswamp is a region in southwest Cyber City still left unclaimed by the corporations. The de-facto home of the Cyber City underworld, Uniswamp is infested by renegade shills who do anything to turn a quick buck. Without proper guidance, all those who enter the UniSwamp are consumed by its devious inhabitants, leaving them rekt.",
    "metadata" : {
      "animation_url" : "https://superfarm-images.s3.amazonaws.com/EllioTrades/uniswamp-epic.mp4",
      "attributes" : [ {
        "trait_type" : "Name",
        "value" : "UniSwamp"
      }, {
        "trait_type" : "Variant",
        "value" : "3D Animated"
      }, {
        "trait_type" : "Rarity",
        "value" : "Epic"
      }, {
        "display_type" : "number",
        "trait_type" : "Vote Power",
        "value" : 5
      }, {
        "max_value" : 50,
        "trait_type" : "Issue",
        "value" : 9
      } ],
      "collection" : "EllioTrades",
      "description" : "The UniSwamp is ground zero for warfare with The Institution and its army of Shills. Technically, “District 16”, Uniswamp is a region in southwest Cyber City still left unclaimed by the corporations. The de-facto home of the Cyber City underworld, Uniswamp is infested by renegade shills who do anything to turn a quick buck. Without proper guidance, all those who enter the UniSwamp are consumed by its devious inhabitants, leaving them rekt.",
      "groupSize" : 50,
      "image" : "https://superfarm-images.s3.amazonaws.com/EllioTrades/uniswamp-epic.png",
      "issue" : 9,
      "name" : "UniSwamp",
      "type" : "video/mp4",
      "video" : "https://superfarm-images.s3.amazonaws.com/EllioTrades/uniswamp-epic.mp4"
    },
    "metadata_url" : "https://superfarm-metadata.s3.amazonaws.com/EllioTrades/0000000000000000000000000000000c00000000000000000000000000000009.json",
    "file_url" : "https://superfarm-images.s3.amazonaws.com/EllioTrades/uniswamp-epic.png",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0xafb44cef938b1be600a4331bf9904f6cec2fcac3_t_4083388403051261561560495289181218537481_raw_asset.png",
    "owner_addresses" : [ "0x86872bf79c77cc9f4244d70ede7a8a7a69a6864e" ]
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

