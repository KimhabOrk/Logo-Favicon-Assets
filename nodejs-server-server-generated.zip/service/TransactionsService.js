'use strict';


/**
 * Retrieve contract sales statistics
 * Retrieve in-depth sales statistics about a contract from OpenSea. Includes statistics such as floor price, total volume, sales, etc. Updated with 1-hour interval.  #### Useful for: * Analysis and ranking of NFT collections. * Tracking NFT collections by sales, etc.  #### Related: * To query transactions from a contract, see [Retrieve transactions by contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MzAxNDQ3NzY-retrieve-transactions-by-contract). * To get all NFTs of a contract, see [Retrieve contract NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjAzNDUzNTQ-retrieve-contract-nf-ts).
 *
 * contract_address String 
 * chain String Blockchain where the collection has been minted.
 * returns CollectionStatsResponse
 **/
exports.collection_stats_v0_transactions_stats__contract_address__get = function(contract_address,chain) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "statistics" : {
    "one_day_volume" : 194.7981,
    "one_day_change" : 0.4513354577078356,
    "one_day_sales" : 42,
    "one_day_average_price" : 4.63805,
    "seven_day_volume" : 1099.074207520107,
    "seven_day_change" : -0.052033968595019554,
    "seven_day_sales" : 342,
    "seven_day_average_price" : 3.213667273450605,
    "thirty_day_volume" : 11672.513885632954,
    "thirty_day_change" : -0.2564477340345068,
    "thirty_day_sales" : 3635,
    "thirty_day_average_price" : 3.211145498110854,
    "total_volume" : 27370.823769036146,
    "total_sales" : 13988,
    "total_supply" : 9999,
    "total_minted" : 9999,
    "num_owners" : 5250,
    "average_price" : 1.956736042967983,
    "market_cap" : 32133.4590672326,
    "floor_price" : 2.4
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve transactions by an account
 * Returns all on-chain transactions as well as OpenSea and Rarible order book data for the specified account (i.e. wallet) address. Can be set to `include` transactions such as `mint`, `burn`, `transfer_from`, `transfer_to`, `list`, `buy`, `sell`  and OpenSea order book data such as `make_bid` and `get_bid`, or `all` which includes all transactions. Ethereum mainnet is supported.  #### Useful for: * Tracking all transactions made by an account. * Building analytics and monitoring solutions.  #### Related: * To query transactions from a contract, see [Retrieve transactions by contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MzAxNDQ3NzY-retrieve-transactions-by-contract). * To query transactions for an NFT, see [Retrieve transactions by NFT](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MzAxNDQ3NzU-retrieve-transactions-by-nft).
 *
 * account_address String 
 * chain String Blockchain from which to query NFT transactions.
 * type List Transaction type. You can specify the event types as an array. `all` returns all transaction types.
 * page_size Integer The number of results returned per page. Limit can range between 1 and 50, and the default is 50. (optional)
 * continuation String Continuation. Pass this value from the previous response to fetch the next page. (optional)
 * returns TransactionsByAccountResponse
 **/
exports.transactions_by_account_v0_transactions_accounts__account_address__get = function(account_address,chain,type,page_size,continuation) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "transactions" : {
    "type" : "sale",
    "buyer_address" : "0xc2d131a52a7bc75f6558588d010d649e02710115",
    "seller_address" : "0xc2d131a52a7bc75f6558588d010d649e02710115",
    "nft" : {
      "contract_type" : "ERC1155_lazy",
      "contract_address" : "0xb66a603f4cfe17e3d27b87a8bfcad319856518b8",
      "token_id" : "15358604318467100856391476616408347066873708425523410565866333184395837440001",
      "metadata_url" : "ipfs://QmUNeWBXz4pJkBzMAaPTXS4dUXkHyVNsrfVTbN4bEsJnW1",
      "creators" : [ {
        "account_address" : "0x21f4a9780a52c7a8ca5e30bac89a6b0e2722bf65",
        "creator_share" : "10000"
      } ],
      "royalties" : [ {
        "account_address" : "0x21f4a9780a52c7a8ca5e30bac89a6b0e2722bf65",
        "royalty_share" : "1000"
      } ],
      "signatures" : [ "0xde8ee69a90450466de44e0025aec715d621afbcc1ad11361cc9d63666a7e3f3e33eb72d48f2753f6e5d414967ba5ae06d00e39d1f53e99d419038011c2f159f51b" ],
      "total" : 5000
    },
    "quantity" : 1,
    "price_details" : {
      "asset_type" : "ERC20",
      "contract_address" : "0xaa75b8c9e01ac2e9fc041a39d36a6536540b2072",
      "price" : "0.071",
      "price_usd" : 271.5
    },
    "transaction_hash" : "0x1c3b3e05961e5010e1b13d60a550ee9e14f9f3ef99a4d81e266b2b2067d6df87",
    "block_hash" : "0x8ad765098c04fa1b566b35848e951e99257a161a50a8732f06aef393f4e18dae",
    "block_number" : 13733126,
    "transaction_date" : "2021-12-03T10:37:41",
    "marketplace" : "opensea"
  },
  "continuation" : "1638479526000_61a936bd60c2ce3a0c68cd6f"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve transactions by contract
 * Returns all on-chain transactions as well as OpenSea and Rarible order book data for the specified contract. Can be set to `include` transactions such as `transfer`, `burn`, `mint`, `bid`, `list` and `sale`, or `all` which includes all transactions. Ethereum mainnet is supported.  #### Useful for: * Tracking all transactions of all NFT tokens in a contract. * Building analytics and monitoring solutions.  #### Related: * To query sales statistics of an NFT collection, see [Retrieve contract sales statistics](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MzEyODQ1MTc-retrieve-contract-sales-statistics). * To query transactions for an NFT, see [Retrieve transactions by NFT](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MzAxNDQ3NzU-retrieve-transactions-by-nft). * To query transactions from an account, see [Retrieve transactions by account](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MzAxNDQ3NzQ-retrieve-transactions-by-an-account).
 *
 * contract_address String 
 * chain String Blockchain from which to query NFT transactions.
 * type List Transaction type. You can specify the event types as an array. `all` returns all transaction types.
 * page_size Integer The number of results returned per page. Limit can range between 1 and 50, and the default is 50. (optional)
 * continuation String Continuation. Pass this value from the previous response to fetch the next page. (optional)
 * returns TransactionsByContractResponse
 **/
exports.transactions_by_contract_v0_transactions_nfts__contract_address__get = function(contract_address,chain,type,page_size,continuation) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "transactions" : {
    "type" : "transfer",
    "transfer_from" : "0xaf8acfa2d093a3569f9b1a2fd3c596d3b5d8f69d",
    "transfer_to" : "0xa42f6807522e4c786835e253c0735f130e58aa9d",
    "contract_address" : "0xb66a603f4cfe17e3d27b87a8bfcad319856518b8",
    "token_id" : "79400006447981872162108805936960249632419041130515543620398493819452073705492",
    "quantity" : 1,
    "transaction_hash" : "0x117cce93c9f67a19273f53caf6cba46485f9be03c04d0131b1df0f15ce005c90",
    "block_hash" : "0x80907f3c8bcaa5bc313b2c4114750aa38d255e740427404cefb99c231ebf9fe5",
    "block_number" : 13732674,
    "transaction_date" : "2021-12-03T09:00:46"
  },
  "continuation" : "1638479526000_61a936bd60c2ce3a0c68cd6f"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve transactions by NFT
 * Returns all on-chain transactions as well as OpenSea and Rarible order book data for the specified NFT token. Can be set to `include` transactions such as `transfer`, `burn`, `mint`, `bid`, `list` and `sale`, or `all` which includes all transactions. Ethereum mainnet is supported.  #### Useful for: * Tracking all transactions of an NFT token. * Building analytics and monitoring solutions.  #### Related: * To query transactions from a contract, see [Retrieve transactions by contract](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MzAxNDQ3NzY-retrieve-transactions-by-contract). * To query transactions from an account, see [Retrieve transactions by account](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MzAxNDQ3NzQ-retrieve-transactions-by-an-account).
 *
 * contract_address String 
 * token_id String 
 * chain String Blockchain of the NFT from which to query transactions.
 * type List Transaction type. You can specify the event types as an array. `all` returns all transaction types.
 * page_size Integer The number of results returned per page. Limit can range between 1 and 50, and the default is 50. (optional)
 * continuation String Continuation. Pass this value from the previous response to fetch the next page. (optional)
 * returns TransactionsByTokenResponse
 **/
exports.transactions_by_token_v0_transactions_nfts__contract_address___token_id__get = function(contract_address,token_id,chain,type,page_size,continuation) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "transactions" : {
    "type" : "list",
    "lister_address" : "0xb4cdc8dfd9ce9bf647f38cd8278036c0aacdc91e",
    "nft" : {
      "contract_type" : "ERC1155_lazy",
      "contract_address" : "0xb66a603f4cfe17e3d27b87a8bfcad319856518b8",
      "token_id" : "15358604318467100856391476616408347066873708425523410565866333184395837440001",
      "metadata_url" : "ipfs://QmUNeWBXz4pJkBzMAaPTXS4dUXkHyVNsrfVTbN4bEsJnW1",
      "creators" : [ {
        "account_address" : "0x21f4a9780a52c7a8ca5e30bac89a6b0e2722bf65",
        "creator_share" : "10000"
      } ],
      "royalties" : [ {
        "account_address" : "0x21f4a9780a52c7a8ca5e30bac89a6b0e2722bf65",
        "royalty_share" : "1000"
      } ],
      "signatures" : [ "0xde8ee69a90450466de44e0025aec715d621afbcc1ad11361cc9d63666a7e3f3e33eb72d48f2753f6e5d414967ba5ae06d00e39d1f53e99d419038011c2f159f51b" ],
      "total" : 5000
    },
    "quantity" : 1,
    "listing_details" : {
      "asset_type" : "ERC20",
      "contract_address" : "0xaa75b8c9e01ac2e9fc041a39d36a6536540b2072",
      "price" : "0.071",
      "price_usd" : 271.5
    },
    "transaction_date" : "2021-12-03T01:28:55.961",
    "marketplace" : "opensea"
  },
  "continuation" : "1638479526000_61a936bd60c2ce3a0c68cd6f"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

