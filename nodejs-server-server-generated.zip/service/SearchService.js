'use strict';


/**
 * Multi-chain NFT search
 * Searches NFTs across multiple chains using a text query, specifically the ```name``` and ```description``` fields from the metadata. You can think of it like performing a search on Google. It's designed to help you find the one or the most closest NFT results you're looking for.  Ethereum and Polygon are supported, including multi-chain search.  #### Useful for: * Finding NFTs by their name and/or description. * Quickly integrating NFT search to your application.  #### Related: * To get NFT recommendations, use [Recommend similar NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM4MzI-find-similar-nf-ts-w-url). * To find duplicate NFTs, use [Find duplicate NFTs](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE0MDYzODY-find-counterfeit-nf-ts-w-file-upload).
 *
 * text String Search query.
 * chain String Blockchain from which to query NFTs. (optional)
 * page_number Integer The page number of the results to return. The first page is 1. (optional)
 * page_size Integer The number of results returned per page. Limit can range between 1 and 50, and the default is 50. (optional)
 * order_by order_by Results ordering criteria. Deafult ordering criteria is search relevance. (optional)
 * sort_order sort_order Results will be sorted in this order (ascending/descending). (optional)
 * filter_by_contract_address String Results will only include NFTs from this contract address. (optional)
 * returns src__service__text_search__entities__TextSearchResponse
 **/
exports.text_search_v0_search_get = function(text,chain,page_number,page_size,order_by,sort_order,filter_by_contract_address) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "search_results" : [ {
    "chain" : "ethereum",
    "contract_address" : "0x12f28e2106ce8fd8464885b80ea865e98b465149",
    "token_id" : "100030071",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0x12f28e2106ce8fd8464885b80ea865e98b465149_t_100030071_raw_asset.png",
    "name" : "Name field value in NFT metadata",
    "description" : "Description field value in NFT metadata",
    "mint_date" : "2020-10-29T15:03:54.838612"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

