'use strict';


/**
 * Return minted NFT
 * Based on the minting transaction hash, returns the minted NFT's contract address and the token ID.  Note that blockchains can be slow and minting can take some time.
 *
 * chain chain_6 Blockchain where the NFTs smart contract lives
 * transaction_hash String Transaction hash that was returned from mint NFT endpoint
 * returns GetMintedNftResponse
 **/
exports.get_minted_nft_get_minted_nft_get = function(chain,transaction_hash) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "contract_address" : "0x47c7ff137d7a6644a9a96f1d44f5a6f857d9023f",
  "token_id" : "2"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Upload a file to IPFS
 * If you already have or prefer files hosted in your own server, you can skip this step. If you do not have a file uploaded, we recommend you to use this endpoint for distributed storage provided by [IPFS (industry standard)](https://docs.ipfs.io/concepts/what-is-ipfs/) to guarantee the immutability of your file.  Returns the IPFS URL of the file, which will be included in the NFT's metadata under [/ipfs_upload_metadata](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTM4MTY5OTY-upload-metadata-to-ipfs).  **Maximum supported filesize is 20MB**     
 *
 * returns IpfsFileUploadResponse
 **/
exports.ipfs_upload_file_ipfs_upload_file_post = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "ipfs_url" : "https://ipfs.io/ipfs/QmRModSr9gQTSZrbfbLis6mw21HycZyqMA3j8YMRD11nAQ",
  "file_name" : "name.jpeg",
  "content_type" : "image/jpeg",
  "file_size" : 85138,
  "file_size_mb" : 0.0812
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Upload metadata to IPFS
 * Upload NFT metadata to IPFS as a JSON file. Specify the NFTs name, a short description and the file URL (which you host yourself or have uploaded with [/ipfs_upload_file](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTM4MTY5OTU-upload-a-file-to-ipfs)).  You can also add a list of attributes according to:  [https://docs.opensea.io/docs/metadata-standards#attributes](https://docs.opensea.io/docs/metadata-standards#attributes)  Returns the IPFS URI of the uploaded JSON file, that can be used in [/mint_nft](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTM4MTY5OTc-mint-an-nft).     
 *
 * body Src__service__minting__deprecated__entities__IpfsMetadataUploadRequest 
 * returns src__service__minting__deprecated__entities__IpfsMetadataUploadResponse
 **/
exports.ipfs_upload_metadata_ipfs_upload_metadata_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "metadata_ipfs_uri" : "ipfs://QmTz7dGHvXghNuh3V64QBwHPXva4chpMR7frpfxCaxvhd4"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Mint an NFT
 * Mint an NFT on [Polygon](https://decrypt.co/resources/what-is-polygon-matic-and-why-it-matters-for-ethereum) or [Rinkeby](https://ethereum.org/en/developers/docs/networks) by entering a contract address, metadata URI and the owner's wallet address.  If you are missing the contract address, see [POST /contract](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTc0MDA0NDg-deploy-an-nft-contract).  If you are missing the metadata URI, see [/ipfs_upload_metadata](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTM4MTY5OTY-upload-metadata-to-ipfs).  Returns contract address and transaction hash of the NFT minting transaction.  After minting, the NFT will appear in the specified owner's wallet. In a few minutes, you can see the minted NFT on OpenSea either in your profile (if you minted to your own wallet) or at:  Polygon [https://opensea.io/assets/matic/](https://opensea.io/assets/matic/)<contract_address>/<token_id>  Rinkeby [https://testnets.opensea.io/assets/](https://testnets.opensea.io/assets/)<contract_address>/<token_id>  **Maximum supported filesize is 20MB.**  **You can mint up to 1000 NFTs for free per chain.**     
 *
 * body MintNftRequest 
 * returns MintNftResponse
 **/
exports.mint_nft_mint_nft_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "contract_address" : "0xC8D297D7b496f86673551c933815B47973FC4a0e",
  "transaction_hash" : "0xcbbe6072d7aa48b9774ed8b15e7f298489c5e965b32aa468ca520b30aba649a1",
  "transaction_external_url" : "https://polygonscan.com/tx/0xcbbe6072d7aa48b9774ed8b15e7f298489c5e965b32aa468ca520b30aba649a1",
  "metadata_uri" : "ipfs://QmTz7dGHvXghNuh3V64QBwHPXva4chpMR7frpfxCaxvhd4",
  "mint_to_address" : "0x5FDd0881Ef284D6fBB2Ed97b01cb13d707f91e42"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Mint an NFT with file upload
 * Upload a file and the metadata to [IPFS](https://docs.ipfs.io/concepts/what-is-ipfs/), and mint an NFT on [Polygon](https://decrypt.co/resources/what-is-polygon-matic-and-why-it-matters-for-ethereum) or [Rinkeby](https://ethereum.org/en/developers/docs/networks).  You need to enter a contract address, the NFT's name and description, and the owner's wallet address. This is a combined and simplified version of [/ipfs_upload_file](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTM4MTY5OTU-upload-a-file-to-ipfs), [/ipfs_upload_metadata](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTM4MTY5OTY-upload-metadata-to-ipfs) and [/mint_nft](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTM4MTY5OTc-mint-an-nft).  In case you are missing the contract address, then see [POST /contract](https://docs.digiofficial.xyz/docs/digiofficial/branches/deprecated/b3A6MTc0MDA0NDg-deploy-an-nft-contract).  Returns Contract address and Transaction hash of the NFT minting transaction.  After minting, the NFT will appear in the specified owner's wallet. In a few minutes, you can see the minted NFT on OpenSea either in your profile (if you minted to your own wallet) or at:  Polygon https://opensea.io/assets/matic/<contract_address>/<token_id>  Rinkeby https://testnets.opensea.io/assets/<contract_address>/<token_id>  **Maximum supported filesize is 20MB.**  **You can mint up to 1000 NFTs for free per chain.**
 *
 * chain MintNftRequestChain 
 * contract_address String 
 * name String 
 * description String 
 * mint_to_address String 
 * returns MintNftWithUploadResponse
 **/
exports.mint_nft_with_upload_mint_nft_with_upload_post = function(chain,contract_address,name,description,mint_to_address) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "chain" : "polygon",
  "contract_address" : "0x47c7ff137d7a6644a9a96f1d44f5a6f857d9023f",
  "transaction_hash" : "0x6eb71286f4875bf48be7834c1ff285910583705714f5a5acff67489f94e14954",
  "transaction_external_url" : "https://polygonscan.com/tx/0x6eb71286f4875bf48be7834c1ff285910583705714f5a5acff67489f94e14954",
  "mint_to_address" : "0x5FDd0881Ef284D6fBB2Ed97b01cb13d707f91e42",
  "name" : "DiGiOfficial's NFT.xyz",
  "description" : "One-Stop & Simple NFT Infrastructure & APIs for Developers"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

