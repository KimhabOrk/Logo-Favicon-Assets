'use strict';


/**
 * Find counterfeit NFTs w/token ID
 * Analyzes the input nft image passed with ```chain```,  ```contract_address``` and  ```token_id```,  and returns duplicates (i.e. counterfeits) against it. Uses state of the art computer vision AI to match the input image against all ETH & Polygon NFT images in our database and returns duplicates which pass the ```threshold```.  **Supported file formats: JPG, JPEG, PNG, PPM, BMP, PGM, TIF, TIFF, WebP.**  #### Useful for: * **Increase customer trust and lower fraud** - enable users to see if an NFT is unique or already minted/sold somewhere else by showing information on existing duplicate NFTs. * **Credit and protect creators** - build processes that defend against IP theft and/or credit the original authors when their work has been used in similar NFTs. * **Enable and attract large IP holders (e.g. Disney)** to upload content as NFTs by ensuring automatic copyright protection (similar to YouTube's Content ID). * **Finding original owner** - find the NFT owner simply with the NFT image.  #### Related: * To find similar NFTs which can be used as recommendations, see [Find similar NFTs w/URL](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM4MzI-find-similar-nf-ts-w-url) or [Find similar NFTs w/file upload](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM4MzM-find-similar-nf-ts-w-file-upload).
 *
 * body ContentIdNftRequest 
 * returns ContentIdResponse
 **/
exports.similar_nfts_address_v0_duplicates_tokens_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "is_similar" : true,
  "similar_nfts" : [ {
    "contract_address" : "0xb47e3cd837ddf8e4c57f05d70ab865de6e193bbb",
    "token_id" : "3100",
    "chain" : "ethereum",
    "similarity" : 0.999998,
    "file_url" : "https://www.larvalabs.com/cryptopunks/cryptopunk3100.png",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0xb47e3cd837ddf8e4c57f05d70ab865de6e193bbb_t_3100_raw_asset.png",
    "metadata_url" : "https://api.niftygateway.com/beeple/100030071/",
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    },
    "mint_date" : "2020-10-29T15:03:54.838612"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Find counterfeit NFTs w/url
 * Analyzes the input image passed with ```url``` and returns duplicates (i.e. counterfeits) against it. Uses state of the art computer vision AI to match the input image against all ETH & Polygon NFT images in our database and returns duplicates which pass the ```threshold```.  **Supported file formats: JPG, JPEG, PNG, PPM, BMP, PGM, TIF, TIFF, WebP.**  #### Useful for: * **Increase customer trust and lower fraud** - enable users to see if an NFT is unique or already minted/sold somewhere else by showing information on existing duplicate NFTs. * **Credit and protect creators** - build processes that defend against IP theft and/or credit the original authors when their work has been used in similar NFTs. * **Enable and attract large IP holders (e.g. Disney)** to upload content as NFTs by ensuring automatic copyright protection (similar to YouTube's Content ID). * **Finding original owner** - find the NFT owner simply with the NFT image.  #### Related: * To find similar NFTs which can be used as recommendations, see [Find similar NFTs w/URL](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM4MzI-find-similar-nf-ts-w-url) or [Find similar NFTs w/file upload](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM4MzM-find-similar-nf-ts-w-file-upload).
 *
 * body ContentIdUrlRequest 
 * returns ContentIdResponse
 **/
exports.similar_nfts_url_v0_duplicates_urls_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "is_similar" : true,
  "similar_nfts" : [ {
    "contract_address" : "0xb47e3cd837ddf8e4c57f05d70ab865de6e193bbb",
    "token_id" : "3100",
    "chain" : "ethereum",
    "similarity" : 0.999998,
    "file_url" : "https://www.larvalabs.com/cryptopunks/cryptopunk3100.png",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0xb47e3cd837ddf8e4c57f05d70ab865de6e193bbb_t_3100_raw_asset.png",
    "metadata_url" : "https://api.niftygateway.com/beeple/100030071/",
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    },
    "mint_date" : "2020-10-29T15:03:54.838612"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Find counterfeit NFTs w/file upload
 * Analyzes the input image passed with ```file``` and returns duplicates (i.e. counterfeits) against it. Uses state of the art computer vision AI to match the input image against all ETH & Polygon NFT images in our database and returns duplicates which pass the ```threshold```.  **Supported file formats: JPG, JPEG, PNG, PPM, BMP, PGM, TIF, TIFF, WebP.**  #### Useful for: * **Increase customer trust and lower fraud** - enable users to see if an NFT is unique or already minted/sold somewhere else by showing information on existing duplicate NFTs. * **Credit and protect creators** - build processes that defend against IP theft and/or credit the original authors when their work has been used in similar NFTs. * **Enable and attract large IP holders (e.g. Disney)** to upload content as NFTs by ensuring automatic copyright protection (similar to YouTube's Content ID). * **Finding original owner** - find the NFT owner simply with the NFT image.  #### Related: * To find similar NFTs which can be used as recommendations, see [Find similar NFTs w/URL](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM4MzI-find-similar-nf-ts-w-url) or [Find similar NFTs w/file upload](https://docs.digiofficial.xyz/docs/digiofficial/b3A6MjE2NjM4MzM-find-similar-nf-ts-w-file-upload).
 *
 * page_number Integer The page number of the results to return. The first page is 1. (optional)
 * page_size Integer The number of results returned per page. Limit can range between 1 and 50, and the default is 50. (optional)
 * threshold BigDecimal Threshold for classifying an NFT as a counterfeit. (optional)
 * filter_out_contract_address String NFTs from this contract address will be filtered out. Useful for examples where the whole NFT collection is visually very similar e.g. CryptoPunks. (optional)
 * returns ContentIdResponse
 **/
exports.similar_nfts_v0_duplicates_files_post = function(page_number,page_size,threshold,filter_out_contract_address) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "response" : "OK",
  "is_similar" : true,
  "similar_nfts" : [ {
    "contract_address" : "0xb47e3cd837ddf8e4c57f05d70ab865de6e193bbb",
    "token_id" : "3100",
    "chain" : "ethereum",
    "similarity" : 0.999998,
    "file_url" : "https://www.larvalabs.com/cryptopunks/cryptopunk3100.png",
    "cached_file_url" : "https://storage.googleapis.com/sentinel-nft/raw-assets/c_0xb47e3cd837ddf8e4c57f05d70ab865de6e193bbb_t_3100_raw_asset.png",
    "metadata_url" : "https://api.niftygateway.com/beeple/100030071/",
    "metadata" : {
      "description" : "ok first off it's a fucking dollar, if you need extra convincing from some BS artist's notes wether you want to spend a dollar on this i will punch you in the god damn face. smash the buy button ya jabroni.",
      "background_color" : "ffffff",
      "external_url" : "https://niftygateway.com/#/",
      "image" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.png",
      "name" : "POLITICS IS BULLSHIT #71/100",
      "animation_url" : "https://res.cloudinary.com/nifty-gateway/video/upload/v1603975889/Beeple/POLITICAL_BULLSHIT_uqbc8x.mp4"
    },
    "mint_date" : "2020-10-29T15:03:54.838612"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

