'use strict';

var utils = require('../utils/writer.js');
var ContractsMetadataAssets = require('../service/ContractsMetadataAssetsService');

module.exports.nft_details_v0_nfts__contract_address___token_id__get = function nft_details_v0_nfts__contract_address___token_id__get (req, res, next, contract_address, token_id, chain, refresh_metadata) {
  ContractsMetadataAssets.nft_details_v0_nfts__contract_address___token_id__get(contract_address, token_id, chain, refresh_metadata)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.nfts_by_contract_v0_nfts__contract_address__get = function nfts_by_contract_v0_nfts__contract_address__get (req, res, next, contract_address, chain, page_number, page_size, include, refresh_metadata) {
  ContractsMetadataAssets.nfts_by_contract_v0_nfts__contract_address__get(contract_address, chain, page_number, page_size, include, refresh_metadata)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.nfts_v0_nfts_get = function nfts_v0_nfts_get (req, res, next, chain, page_size, continuation, include) {
  ContractsMetadataAssets.nfts_v0_nfts_get(chain, page_size, continuation, include)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
