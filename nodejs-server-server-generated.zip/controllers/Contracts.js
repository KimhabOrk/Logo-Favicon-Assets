'use strict';

var utils = require('../utils/writer.js');
var Contracts = require('../service/ContractsService');

module.exports.deploy_contract_v0_contracts_post = function deploy_contract_v0_contracts_post (req, res, next, body) {
  Contracts.deploy_contract_v0_contracts_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get_deployed_contract_v0_contracts__transaction_hash__get = function get_deployed_contract_v0_contracts__transaction_hash__get (req, res, next, transaction_hash, chain) {
  Contracts.get_deployed_contract_v0_contracts__transaction_hash__get(transaction_hash, chain)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.update_contract_v0_contracts_put = function update_contract_v0_contracts_put (req, res, next, body) {
  Contracts.update_contract_v0_contracts_put(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
