'use strict';

var utils = require('../utils/writer.js');
var Search = require('../service/SearchService');

module.exports.text_search_v0_search_get = function text_search_v0_search_get (req, res, next, text, chain, page_number, page_size, order_by, sort_order, filter_by_contract_address) {
  Search.text_search_v0_search_get(text, chain, page_number, page_size, order_by, sort_order, filter_by_contract_address)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
