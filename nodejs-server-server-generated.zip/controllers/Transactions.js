'use strict';

var utils = require('../utils/writer.js');
var Transactions = require('../service/TransactionsService');

module.exports.collection_stats_v0_transactions_stats__contract_address__get = function collection_stats_v0_transactions_stats__contract_address__get (req, res, next, contract_address, chain) {
  Transactions.collection_stats_v0_transactions_stats__contract_address__get(contract_address, chain)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.transactions_by_account_v0_transactions_accounts__account_address__get = function transactions_by_account_v0_transactions_accounts__account_address__get (req, res, next, account_address, chain, type, page_size, continuation) {
  Transactions.transactions_by_account_v0_transactions_accounts__account_address__get(account_address, chain, type, page_size, continuation)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.transactions_by_contract_v0_transactions_nfts__contract_address__get = function transactions_by_contract_v0_transactions_nfts__contract_address__get (req, res, next, contract_address, chain, type, page_size, continuation) {
  Transactions.transactions_by_contract_v0_transactions_nfts__contract_address__get(contract_address, chain, type, page_size, continuation)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.transactions_by_token_v0_transactions_nfts__contract_address___token_id__get = function transactions_by_token_v0_transactions_nfts__contract_address___token_id__get (req, res, next, contract_address, token_id, chain, type, page_size, continuation) {
  Transactions.transactions_by_token_v0_transactions_nfts__contract_address___token_id__get(contract_address, token_id, chain, type, page_size, continuation)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
