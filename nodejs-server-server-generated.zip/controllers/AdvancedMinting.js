'use strict';

var utils = require('../utils/writer.js');
var AdvancedMinting = require('../service/AdvancedMintingService');

module.exports.get_minted_nft_get_minted_nft_get = function get_minted_nft_get_minted_nft_get (req, res, next, chain, transaction_hash) {
  AdvancedMinting.get_minted_nft_get_minted_nft_get(chain, transaction_hash)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.ipfs_upload_file_ipfs_upload_file_post = function ipfs_upload_file_ipfs_upload_file_post (req, res, next) {
  AdvancedMinting.ipfs_upload_file_ipfs_upload_file_post()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.ipfs_upload_metadata_ipfs_upload_metadata_post = function ipfs_upload_metadata_ipfs_upload_metadata_post (req, res, next, body) {
  AdvancedMinting.ipfs_upload_metadata_ipfs_upload_metadata_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.mint_nft_mint_nft_post = function mint_nft_mint_nft_post (req, res, next, body) {
  AdvancedMinting.mint_nft_mint_nft_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.mint_nft_with_upload_mint_nft_with_upload_post = function mint_nft_with_upload_mint_nft_with_upload_post (req, res, next, chain, contract_address, name, description, mint_to_address) {
  AdvancedMinting.mint_nft_with_upload_mint_nft_with_upload_post(chain, contract_address, name, description, mint_to_address)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
