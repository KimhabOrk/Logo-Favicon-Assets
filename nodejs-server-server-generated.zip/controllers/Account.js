'use strict';

var utils = require('../utils/writer.js');
var Account = require('../service/AccountService');

module.exports.account_nfts_account__account_address__nfts_get = function account_nfts_account__account_address__nfts_get (req, res, next, account_address, chain, page_number, page_size, continuation, include) {
  Account.account_nfts_account__account_address__nfts_get(account_address, chain, page_number, page_size, continuation, include)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
