'use strict';

var utils = require('../utils/writer.js');
var Minting = require('../service/MintingService');

module.exports.easy_mint_nft_v0_mints_easy_urls_post = function easy_mint_nft_v0_mints_easy_urls_post (req, res, next, body) {
  Minting.easy_mint_nft_v0_mints_easy_urls_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.easy_mint_nft_with_upload_v0_mints_easy_files_post = function easy_mint_nft_with_upload_v0_mints_easy_files_post (req, res, next, chain, name, description, mint_to_address) {
  Minting.easy_mint_nft_with_upload_v0_mints_easy_files_post(chain, name, description, mint_to_address)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get_batch_minted_nft_v0_mints_batch__transaction_hash__get = function get_batch_minted_nft_v0_mints_batch__transaction_hash__get (req, res, next, transaction_hash, chain) {
  Minting.get_batch_minted_nft_v0_mints_batch__transaction_hash__get(transaction_hash, chain)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get_minted_nft_v0_mints__transaction_hash__get = function get_minted_nft_v0_mints__transaction_hash__get (req, res, next, transaction_hash, chain) {
  Minting.get_minted_nft_v0_mints__transaction_hash__get(transaction_hash, chain)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.mint_batch_nft_v0_mints_customizable_batch_post = function mint_batch_nft_v0_mints_customizable_batch_post (req, res, next, body) {
  Minting.mint_batch_nft_v0_mints_customizable_batch_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.mint_nft_v0_mints_customizable_post = function mint_nft_v0_mints_customizable_post (req, res, next, body) {
  Minting.mint_nft_v0_mints_customizable_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.update_nft_v0_mints_customizable_put = function update_nft_v0_mints_customizable_put (req, res, next, body) {
  Minting.update_nft_v0_mints_customizable_put(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
