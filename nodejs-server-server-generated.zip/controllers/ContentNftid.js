'use strict';

var utils = require('../utils/writer.js');
var ContentNftid = require('../service/ContentNftidService');

module.exports.similar_nfts_similar_nfts_post = function similar_nfts_similar_nfts_post (req, res, next, limit, threshold, contract_address) {
  ContentNftid.similar_nfts_similar_nfts_post(limit, threshold, contract_address)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
