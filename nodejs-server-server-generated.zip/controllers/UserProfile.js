'use strict';

var utils = require('../utils/writer.js');
var UserProfile = require('../service/UserProfileService');

module.exports.get_user_contracts_me_contracts_get = function get_user_contracts_me_contracts_get (req, res, next) {
  UserProfile.get_user_contracts_me_contracts_get()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get_user_minted_nfts_me_minted_nfts_get = function get_user_minted_nfts_me_minted_nfts_get (req, res, next, chain, page_number, page_size) {
  UserProfile.get_user_minted_nfts_me_minted_nfts_get(chain, page_number, page_size)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
