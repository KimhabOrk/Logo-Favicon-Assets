'use strict';

var utils = require('../utils/writer.js');
var Contract = require('../service/ContractService');

module.exports.deploy_contract_contract_post = function deploy_contract_contract_post (req, res, next, body) {
  Contract.deploy_contract_contract_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get_deployed_contract_contract_get = function get_deployed_contract_contract_get (req, res, next, chain, transaction_hash) {
  Contract.get_deployed_contract_contract_get(chain, transaction_hash)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
