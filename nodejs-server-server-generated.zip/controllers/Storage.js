'use strict';

var utils = require('../utils/writer.js');
var Storage = require('../service/StorageService');

module.exports.ipfs_upload_file_v0_files_post = function ipfs_upload_file_v0_files_post (req, res, next) {
  Storage.ipfs_upload_file_v0_files_post()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.ipfs_upload_metadata_v0_metadata_post = function ipfs_upload_metadata_v0_metadata_post (req, res, next, body) {
  Storage.ipfs_upload_metadata_v0_metadata_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
