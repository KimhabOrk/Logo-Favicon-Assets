'use strict';

var utils = require('../utils/writer.js');
var EasyMinting = require('../service/EasyMintingService');

module.exports.get_minted_nft_get_minted_nft_get = function get_minted_nft_get_minted_nft_get (req, res, next, chain, transaction_hash) {
  EasyMinting.get_minted_nft_get_minted_nft_get(chain, transaction_hash)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.mint_nft_with_upload_easy_mint_post = function mint_nft_with_upload_easy_mint_post (req, res, next, chain, name, description, mint_to_address) {
  EasyMinting.mint_nft_with_upload_easy_mint_post(chain, name, description, mint_to_address)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
