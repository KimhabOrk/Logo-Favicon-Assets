'use strict';

var utils = require('../utils/writer.js');
var Nfts = require('../service/NftsService');

module.exports.nft_details_nfts__contract_address___token_id__get = function nft_details_nfts__contract_address___token_id__get (req, res, next, contract_address, token_id, chain) {
  Nfts.nft_details_nfts__contract_address___token_id__get(contract_address, token_id, chain)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.nfts_by_contract_nfts__contract_address__get = function nfts_by_contract_nfts__contract_address__get (req, res, next, contract_address, chain, page_number, page_size, include) {
  Nfts.nfts_by_contract_nfts__contract_address__get(contract_address, chain, page_number, page_size, include)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.nfts_nfts_get = function nfts_nfts_get (req, res, next, chain, page_size, continuation) {
  Nfts.nfts_nfts_get(chain, page_size, continuation)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
