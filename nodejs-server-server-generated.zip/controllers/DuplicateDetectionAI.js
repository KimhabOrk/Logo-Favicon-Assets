'use strict';

var utils = require('../utils/writer.js');
var DuplicateDetectionAI = require('../service/DuplicateDetectionAIService');

module.exports.similar_nfts_address_v0_duplicates_tokens_post = function similar_nfts_address_v0_duplicates_tokens_post (req, res, next, body) {
  DuplicateDetectionAI.similar_nfts_address_v0_duplicates_tokens_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.similar_nfts_url_v0_duplicates_urls_post = function similar_nfts_url_v0_duplicates_urls_post (req, res, next, body) {
  DuplicateDetectionAI.similar_nfts_url_v0_duplicates_urls_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.similar_nfts_v0_duplicates_files_post = function similar_nfts_v0_duplicates_files_post (req, res, next, page_number, page_size, threshold, filter_out_contract_address) {
  DuplicateDetectionAI.similar_nfts_v0_duplicates_files_post(page_number, page_size, threshold, filter_out_contract_address)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
