'use strict';

var utils = require('../utils/writer.js');
var Ownership = require('../service/OwnershipService');

module.exports.account_nfts_v0_accounts__account_address__get = function account_nfts_v0_accounts__account_address__get (req, res, next, account_address, chain, page_number, page_size, continuation, include) {
  Ownership.account_nfts_v0_accounts__account_address__get(account_address, chain, page_number, page_size, continuation, include)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.creator_nfts_v0_accounts_creators__account_address__get = function creator_nfts_v0_accounts_creators__account_address__get (req, res, next, account_address, chain, page_size, continuation, include) {
  Ownership.creator_nfts_v0_accounts_creators__account_address__get(account_address, chain, page_size, continuation, include)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
