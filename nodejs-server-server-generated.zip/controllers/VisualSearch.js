'use strict';

var utils = require('../utils/writer.js');
var VisualSearch = require('../service/VisualSearchService');

module.exports.search_file_visual_search_by_file_post = function search_file_visual_search_by_file_post (req, res, next) {
  VisualSearch.search_file_visual_search_by_file_post()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.search_url_visual_search_by_url_post = function search_url_visual_search_by_url_post (req, res, next, body) {
  VisualSearch.search_url_visual_search_by_url_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.search_visual_search_post = function search_visual_search_post (req, res, next, body) {
  VisualSearch.search_visual_search_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
