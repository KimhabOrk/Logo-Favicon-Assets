'use strict';

var utils = require('../utils/writer.js');
var RecommendationsAI = require('../service/RecommendationsAIService');

module.exports.search_file_v0_recommendations_similar_nfts_files_post = function search_file_v0_recommendations_similar_nfts_files_post (req, res, next, page_number, page_size) {
  RecommendationsAI.search_file_v0_recommendations_similar_nfts_files_post(page_number, page_size)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.search_url_v0_recommendations_similar_nfts_urls_post = function search_url_v0_recommendations_similar_nfts_urls_post (req, res, next, body) {
  RecommendationsAI.search_url_v0_recommendations_similar_nfts_urls_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
