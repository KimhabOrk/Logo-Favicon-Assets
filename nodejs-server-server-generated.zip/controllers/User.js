'use strict';

var utils = require('../utils/writer.js');
var User = require('../service/UserService');

module.exports.get_user_contracts_v0_me_contracts_get = function get_user_contracts_v0_me_contracts_get (req, res, next) {
  User.get_user_contracts_v0_me_contracts_get()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get_user_minted_nfts_v0_me_mints_get = function get_user_minted_nfts_v0_me_mints_get (req, res, next, chain, page_number, page_size) {
  User.get_user_minted_nfts_v0_me_mints_get(chain, page_number, page_size)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get_user_settings_v0_me_settings_get = function get_user_settings_v0_me_settings_get (req, res, next) {
  User.get_user_settings_v0_me_settings_get()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
